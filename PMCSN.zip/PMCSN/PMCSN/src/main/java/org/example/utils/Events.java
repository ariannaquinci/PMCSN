package org.example.utils;


    public class Events {
        //---- PULLMAN EVENTS ----

        public static int ARRIVAL_EVENT_PULLMAN = 1;
        public static int SERVERS_PULLMAN = 4;
        public static int ABANDON_EVENT_PULLMAN = 1;

        //---- CARS EVENTS ----
        // documents' check
        public static int ARRIVAL_EVENT_CAR_DOC = 1;
        public static int SERVERS_CAR_DOC =2;
        public static int ABANDON_EVENT_CAR_DOC = 1;

        // vehicle inspection
        public static int ARRIVAL_EVENT_VEHICLE_INSPECTION = 1;
        public static int SKIP_EVENT_VEHICLE_INSPECTION = 1;
        public static int SERVERS_VEHICLE_INSPECTION =2;
        public static int ABANDON_EVENT_VEHICLE_INSPECTION= 1;

        // CD events
        public static int ARRIVAL_EVENT_CD =1;
        public static int SERVER_CD=1;

        // ---- ALL EVENTS ----
        public static int ALL_EVENTS_CAR_DOC = ARRIVAL_EVENT_CAR_DOC + SERVERS_CAR_DOC + ABANDON_EVENT_CAR_DOC;
        public static int ALL_EVENTS_VEHICLE_INSPECTION = ARRIVAL_EVENT_VEHICLE_INSPECTION + SERVERS_VEHICLE_INSPECTION + SKIP_EVENT_VEHICLE_INSPECTION +ABANDON_EVENT_VEHICLE_INSPECTION ;

        public static int ALL_EVENTS_PULLMAN = ARRIVAL_EVENT_PULLMAN + SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN;
        public static int ALL_EVENTS_CD = ARRIVAL_EVENT_CD +SERVER_CD;
    }


