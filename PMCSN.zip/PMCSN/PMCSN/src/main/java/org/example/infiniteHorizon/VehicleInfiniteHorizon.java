package org.example.infiniteHorizon;

import org.example.libraries.Rngs;
import org.example.utils.Estimate;
import org.example.utils.Rvms;
import org.example.utils.TimeSlot;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import static org.example.utils.ConstantData.*;
import static org.example.utils.Events.*;
import static org.example.utils.NormalService.getServiceNormal;



/*
 *  Model:
 *  ----> document check ----------------------> vehicle inspection ------------>
 *                               |      |                               ^    |
 *                               | P2   |              P_skip           |    | P3
 *                               V      |_______________________________|    V
 */


class MsqT {
    double current;                   /* current time                       */
    double next;                      /* next (most imminent) event time    */
}

class MsqSum {                      /* accumulated sums of                */
    double service;                   /*   service times                    */
    long served;                    /*   number served                    */
}

class MsqEvent {                     /* the next-event list    */
    double t;                         /*   next event time      */
    int x;                         /*   event status, 0 or 1 */
}

public class VehicleInfiniteHorizon {

    static double START = 0.0;            /* initial (open the door)        */
    static double STOP = Double.POSITIVE_INFINITY;        /* terminal (close the door) time */
    static double sarrival = START;

    static List<TimeSlot> slotList = new ArrayList<>();

    public static void main(String[] args) {

        /* population counter for every node */
        long populationDocCheck = 0;
        long populationVehicleInsp = 0;


        int e;      /* next event index */
        int s;      /* server index */

        /* processed jobs counter for every node */
        long indexDocCheck = 0;
        long indexVehicleInsp = 0;


        /* time integrated number for every node */
        double areaDocCheck = 0.0;
        double areaVehicleInsp = 0.0;


        double service;     /* it will contain the service times */

        /* abandons counter for document check and vehicle inspection */
        long abandonsCounterDocCheck = 0;
        long abandonsCounterVehicleInsp = 0;

        /* abandons list for document check and vehicle inspection */
        List<Double> abandonsDocCheck = new ArrayList<>();
        List<Double> abandonsVehicleInsp = new ArrayList<>();

        /* skip list and counter for vehicleInspection */
        List<Double> skipListVehicleInsp = new ArrayList<>();
        long skipCounterVehicleInsp = 0;


        /* first completion for every node */
        double docCheckFirstCompletion = 0;
        double vehicleInspFirstCompletion = 0;

        VehicleInfiniteHorizon m = new VehicleInfiniteHorizon();
        Rngs r = new Rngs();
        r.plantSeeds(0);

        /* time slots initialization */
        for (int f = 0; f < 3; f++) {
            TimeSlot slot = new TimeSlot(PERCENTAGE[f], (int) (LAMBDA*pa/2), 3600* 8 * f, 3600 * 8 * (f + 1) - 1);
            slotList.add(slot);
        }

        /* batch parameters */
        int k =512;
        int b = 2048;
        /* lists for batch simulation */

        /* waiting times */
        List<Double> delaysDocCheck = new ArrayList<>();
        List<Double> delaysVehicleInsp = new ArrayList<>();

        /* response times */
        List<Double> responseTimesDocCheck = new ArrayList<>();
        List<Double> responseTimesVehicleInspect = new ArrayList<>();
        List<Double> responseTimesCumulativeDocCheck =new ArrayList<>();
        List<Double> responseTimesCumulativeVehicleInspection =new ArrayList<>();

        /* utilizations */
        List<Double> utilizationsDocCheck = new ArrayList<>();
        List<Double> utilizationsVehicleInsp = new ArrayList<>();

        /* system populations */
        List<Double> avgPopulationsDocCheck = new ArrayList<>();
        List<Double> avgPopulationsVehicleInsp = new ArrayList<>();

        /* interarrivals */
        List<Double> interarrivalsDocCheck = new ArrayList<>();
        List<Double> interarrivalsVehicleInsp = new ArrayList<>();

        /* abandons */
        List<Double> allAbandonsDocCheck = new ArrayList<>();
        List<Double> allAbandonsVehicleInsp = new ArrayList<>();

        /* service times */
        List<Double> serviceTimesDocCheck = new ArrayList<>();
        List<Double> serviceTimesVehicleInsp = new ArrayList<>();

        /* skips */
        List<Double> skipsCountersVehicleInsp = new ArrayList<>();


        double currentBatchStartingTime = 0;
        double currentFirstArrivalTimeDocCheck = 0;
        double currentFirstArrivalTimeVehicleInsp = 0;

        long batchCounter = 0;

        /* events array initialization */
        MsqEvent[] events = new MsqEvent[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION];

        /* sum array initialization (to keep track of services) */
        MsqSum[] sum = new MsqSum[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION ];
        for (s = 0; s < ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION; s++) {
            events[s] = new MsqEvent();
            sum[s] = new MsqSum();
        }

        /* clock initialization */
        MsqT t = new MsqT();
        t.current = START;

        /* generating the first arrival */
        events[0].t = m.getArrival(r,250 ,t.current);
        events[0].x = 1;

        /* all other servers are initially idle */
        for (s = 1; s < ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION ; s++) {
            events[s].t = START;
            events[s].x = 0;
            sum[s].service = 0.0;
            sum[s].served = 0;
        }



        /* START ITERATION */

        while ((events[0].x != 0)) {


            if (indexDocCheck != 0 && indexDocCheck %b == 0) {

                /* new batch */
                batchCounter++;

                /*DOCUMENT CHECK */
                responseTimesDocCheck.add(areaDocCheck / indexDocCheck);
                if (responseTimesCumulativeDocCheck.isEmpty()) {
                    // Se è il primo, la media cumulata è semplicemente il primo valore
                    responseTimesCumulativeDocCheck.add(responseTimesDocCheck.get(0));
                } else {
                    // Altrimenti, somma l'ultimo valore cumulato e la nuova media
                    double previousCumulative = responseTimesCumulativeDocCheck.get(responseTimesCumulativeDocCheck.size() - 1);
                    double currentResponseTime = responseTimesDocCheck.get(responseTimesDocCheck.size() - 1);
                    double newCumulativeMean = (previousCumulative * (responseTimesCumulativeDocCheck.size()) + currentResponseTime) / (responseTimesCumulativeDocCheck.size() + 1);

                    responseTimesCumulativeDocCheck.add(newCumulativeMean);
                }
                interarrivalsDocCheck.add((events[ARRIVAL_EVENT_CAR_DOC - 1].t - currentFirstArrivalTimeDocCheck) / indexDocCheck);
                allAbandonsDocCheck.add((double) abandonsCounterDocCheck / b);


                double docCheckActualTime = t.current - currentBatchStartingTime;

                avgPopulationsDocCheck.add(areaDocCheck / docCheckActualTime);

                for (s = 1; s <= SERVERS_CAR_DOC; s++)          /* adjust area to calculate */
                    areaDocCheck -= sum[s].service;                 /* averages for the queue */

                delaysDocCheck.add(areaDocCheck / indexDocCheck);

                double sumUtilizations = 0.0;
                double sumServices = 0.0;
                double sumServed = 0.0;


                for (s = 1; s <= SERVERS_CAR_DOC; s++) {
                    sumUtilizations += sum[s].service / docCheckActualTime;
                    sumServices += sum[s].service;
                    sumServed += sum[s].served;
                }

                utilizationsDocCheck.add(sumUtilizations / SERVERS_CAR_DOC);
                serviceTimesDocCheck.add(sumServices / sumServed);


                areaDocCheck = 0;
                indexDocCheck = 0;
                abandonsCounterDocCheck = 0;

                for (s = 1; s <= SERVERS_CAR_DOC; s++) {
                    sum[s].served = 0;
                    sum[s].service = 0;
                }

                /*VEHICLE INSPECTION */

                responseTimesVehicleInspect.add(areaVehicleInsp / indexVehicleInsp);
                if (responseTimesCumulativeVehicleInspection.isEmpty()) {
                    // Se è il primo, la media cumulata è semplicemente il primo valore
                    responseTimesCumulativeVehicleInspection.add(responseTimesVehicleInspect.get(0));
                } else {
                    // Altrimenti, somma l'ultimo valore cumulato e la nuova media
                    double previousCumulative = responseTimesCumulativeVehicleInspection.get(responseTimesCumulativeVehicleInspection.size() - 1);
                    double currentResponseTime = responseTimesVehicleInspect.get(responseTimesVehicleInspect.size() - 1);
                    double newCumulativeMean = (previousCumulative * (responseTimesCumulativeVehicleInspection.size()) + currentResponseTime) / (responseTimesCumulativeVehicleInspection.size() + 1);

                    responseTimesCumulativeVehicleInspection.add(newCumulativeMean);
                }
                interarrivalsVehicleInsp.add((events[ALL_EVENTS_CAR_DOC].t - currentFirstArrivalTimeVehicleInsp) / indexVehicleInsp);
                allAbandonsVehicleInsp.add((double) abandonsCounterVehicleInsp / b);
                skipsCountersVehicleInsp.add((double) skipCounterVehicleInsp);

                double vehicleInspectCurrentTime = t.current - currentBatchStartingTime;

                avgPopulationsVehicleInsp.add(areaVehicleInsp / vehicleInspectCurrentTime);

                for (s = ALL_EVENTS_CAR_DOC + 1; s <= ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION; s++)          /* adjust area to calculate */
                    areaVehicleInsp -= sum[s].service;                                                                /* averages for the queue   */

                delaysVehicleInsp.add(areaVehicleInsp / indexVehicleInsp);

                sumUtilizations = 0.0;
                sumServices = 0.0;
                sumServed = 0.0;


                for (s = ALL_EVENTS_CAR_DOC + 1; s <= ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION; s++) {
                    sumUtilizations += sum[s].service / vehicleInspectCurrentTime;
                    sumServices += sum[s].service;
                    sumServed += sum[s].served;
                }

                utilizationsVehicleInsp.add(sumUtilizations / SERVERS_VEHICLE_INSPECTION);
                serviceTimesVehicleInsp.add(sumServices / sumServed);

                skipCounterVehicleInsp = 0;
                areaVehicleInsp = 0;
                indexVehicleInsp = 0;
                abandonsCounterVehicleInsp = 0;

                for (s = ALL_EVENTS_CAR_DOC + 1; s <= ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION; s++) {
                    sum[s].served = 0;
                    sum[s].service = 0;
                }


                /* final updates */
                currentBatchStartingTime = t.current;
                currentFirstArrivalTimeDocCheck = events[0].t;
                currentFirstArrivalTimeVehicleInsp = events[ALL_EVENTS_CAR_DOC].t;
            }

            if (batchCounter == k)
                break;

            //process skips and abandons if any

            // skip
            if (!skipListVehicleInsp.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 2].t = skipListVehicleInsp.get(0);
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 2].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 2].x = 0;
            }

            // abandons
            if (!abandonsDocCheck.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC - 1].t = abandonsDocCheck.get(0);
                events[ALL_EVENTS_CAR_DOC - 1].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC - 1].x = 0;
            }

            if (!abandonsVehicleInsp.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1].t = t.current;
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1].x = 0;
            }

            e = m.nextEvent(events);    /* next event index */
            t.next = events[e].t;       /* next event time */


            /* update integrals */
            areaDocCheck += (t.next - t.current) * populationDocCheck;
            areaVehicleInsp += (t.next - t.current) * populationVehicleInsp;


            t.current = t.next;     /* advance the clock */

            if (e == ARRIVAL_EVENT_CAR_DOC - 1) {
                /* process an arrival (to the document check) */

                populationDocCheck++;

                /* generate the next arrival */
                events[ARRIVAL_EVENT_CAR_DOC - 1].t = m.getArrival(r, 30 ,t.current);
                if (events[ARRIVAL_EVENT_CAR_DOC - 1].t > STOP)
                    events[ARRIVAL_EVENT_CAR_DOC - 1].x = 0;

                /* if there's no queue, put a job on service */
                if (populationDocCheck <= SERVERS_CAR_DOC) {
                 //   service = m.getService(r, 45, TS_DOC_CARS);

                    service = getServiceNormal(r, (int) (TS_DOC_CARS*0.1),45,10800,TS_DOC_CARS);

                    s = m.findIdleDocCheckServer(events);
                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                    events[s].x = 1;
                }
            } else if (e == ALL_EVENTS_CAR_DOC - 1) {
                /* process an abandon (following the document check) */

                abandonsCounterDocCheck++;
                abandonsDocCheck.remove(0);

            } else if (e == ALL_EVENTS_CAR_DOC) {
                /* arrival at vehicle inspection */

                events[ALL_EVENTS_CAR_DOC].x = 0;

                /* generate an abandon with probability P2 */
                boolean abandon = generateAbandon(r, 60, P2);

                if (abandon) {
                    /* an abandon must be generated -> we must add it to the abandons list and schedule it */
                    double abandonTime = t.current + 0.01;
                    abandonsDocCheck.add(abandonTime);

                } else {
                    /* no abandon -> arrival at the vehicle inspection */

                    populationVehicleInsp++;
                    if (populationVehicleInsp <= SERVERS_VEHICLE_INSPECTION) {
                     //   service = m.getService(r, 75, TS_VEHICLE_INSPECTION_CARS);
                        service = getServiceNormal(r, (int) (TS_VEHICLE_INSPECTION_CARS*0.2),75, 10800,TS_VEHICLE_INSPECTION_CARS);

                        s = m.findIdleVehicleInspServer(events);
                        sum[s].service += service;
                        sum[s].served++;
                        events[s].t = t.current + service;
                        events[s].x = 1;
                    }
                }
            } else if ((e > ALL_EVENTS_CAR_DOC) && (e <= ALL_EVENTS_CAR_DOC +SERVERS_VEHICLE_INSPECTION)) {
                /* service on one of the vehicle inspection servers */
                boolean skip= generateSkipAlternative(r, 90,populationVehicleInsp - SERVERS_VEHICLE_INSPECTION);
                if (skip) {

                    double skipTime = t.current + 0.01;
                    skipListVehicleInsp.add(skipTime);

                } else {

                    if (vehicleInspFirstCompletion == 0)
                        vehicleInspFirstCompletion = t.current;

                    indexVehicleInsp++;
                    populationVehicleInsp--;

                    // generate an abandon with probability P3
                    boolean abandon = generateAbandon(r, 105, P3);
                    if (abandon) {

                        // an abandon must be generated -> we must add it to the abandons list and schedule it
                        double abandonTime = t.current + 0.02;
                        abandonsVehicleInsp.add(abandonTime);
                    }
                }
                /* if there's queue, put a job on service on this server */
                s = e;
                if (populationVehicleInsp >= SERVERS_VEHICLE_INSPECTION) {
                    //service = m.getService(r, 120, TS_VEHICLE_INSPECTION_CARS);
                    service = getServiceNormal(r, (int) (TS_VEHICLE_INSPECTION_CARS*0.2), 120, 10800,TS_VEHICLE_INSPECTION_CARS);

                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                } else {
                    /* if there's no queue, deactivate this server */
                    events[s].x = 0;

                }

            } else if (e == ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 2) {
                /* skip vehicle inspection */

                indexVehicleInsp++;
                populationVehicleInsp--;
                skipCounterVehicleInsp++;
                skipListVehicleInsp.remove(0);

            }
            else if (e == ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1) {
                /* abandon after vehicle inspection */

                abandonsCounterVehicleInsp++;
                abandonsVehicleInsp.remove(0);

            } else {
                /* document check */
                if (docCheckFirstCompletion == 0)
                    docCheckFirstCompletion = t.current;

                indexDocCheck++;
                populationDocCheck--;

                /* generate an arrival at document check */
                events[ALL_EVENTS_CAR_DOC].t = t.current;
                events[ALL_EVENTS_CAR_DOC].x = 1;

                /* if there's queue, put a job in queue on service on this server */
                s = e;
                if (populationDocCheck >= SERVERS_CAR_DOC) {
                  //  service = m.getService(r, 225, TS_DOC_CARS);
                    service = getServiceNormal(r, (int) (TS_DOC_CARS*0.1),225, 10800,TS_DOC_CARS);

                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                } else {
                    /* if there's no queue, deactivate this server */
                    events[s].x = 0;
                }
            }

        }

        System.out.println("END OF ITERATION");


        /* BATCH SIMULATION RESULTS */

        System.out.println("Completed " + batchCounter + " batches");
        System.out.println();

        List<Double> sumResponseTimes = new ArrayList<>();

        // calculation of the total response time
        for (int i = 0; i < responseTimesDocCheck.size(); i++) {

            double sumRT = responseTimesDocCheck.get(i) + responseTimesVehicleInspect.get(i);
            sumResponseTimes.add(sumRT);
        }

        /* files creation for interval estimation */
        String directory = "batch_reports";

        /* DOCUMENT CHECK */
        writeFile(delaysDocCheck, directory, "delays_doc_check");
        writeFile(responseTimesDocCheck, directory, "response_times_doc_check");
        writeFile(utilizationsDocCheck, directory, "utilizations_doc_check");
        writeFile(avgPopulationsDocCheck, directory, "populations_doc_check");
        writeFile(interarrivalsDocCheck, directory, "interarrivals_doc_check");
        writeFile(allAbandonsDocCheck, directory, "abandons_doc_check");
        writeFile(serviceTimesDocCheck, directory, "service_times_doc_check");
        writeFile(responseTimesCumulativeDocCheck, directory, "cumulative_response_times_doc_check");

        /* VEHICLE INSPECTION */
        writeFile(delaysVehicleInsp, directory, "delays_vehicle_inspection");
        writeFile(responseTimesVehicleInspect, directory, "response_times_vehicle_inspection");
        writeFile(utilizationsVehicleInsp, directory, "utilizations_vehicle_inspection");
        writeFile(avgPopulationsVehicleInsp, directory, "populations_vehicle_inspection");
        writeFile(interarrivalsVehicleInsp, directory, "interarrivals_vehicle_inspection");
        writeFile(allAbandonsVehicleInsp, directory, "abandons_vehicle_inspection");
        writeFile(serviceTimesVehicleInsp, directory, "service_times_vehicle_inspection");
        writeFile(skipsCountersVehicleInsp, directory, "skips_vehicle_inspection");
        writeFile(responseTimesCumulativeDocCheck, directory, "cumulative_response_times_doc_check");

        writeFile(responseTimesCumulativeVehicleInspection, directory, "cumulative_response_times_vi");
        writeFile(sumResponseTimes, directory, "total_response_times");
        /* INTERVAL ESTIMATION */

        Estimate estimate = new Estimate();
        List<String> filenames = List.of("response_times_doc_check", "delays_doc_check", "utilizations_doc_check", "interarrivals_doc_check", "abandons_doc_check", "service_times_doc_check", "populations_doc_check",
                "response_times_vehicle_inspection", "delays_vehicle_inspection", "utilizations_vehicle_inspection", "interarrivals_vehicle_inspection", "abandons_vehicle_inspection", "service_times_vehicle_inspection", "populations_vehicle_inspection", "skips_vehicle_inspection"
        );

        for (String filename : filenames) {
            estimate.createInterval(directory, filename);
        }

    }

    public static void writeFile(List<Double> list, String directoryName, String filename) {
        File directory = new File(directoryName);
        BufferedWriter bw = null;

        try {
            if (!directory.exists())
                directory.mkdirs();

            File file = new File(directory, filename + ".dat");

            if (!file.exists())
                file.createNewFile();

            FileWriter writer = new FileWriter(file);
            bw = new BufferedWriter(writer);


            for (int i = 0; i < list.size(); i++) {
                bw.append(String.valueOf(list.get(i)));
                bw.append("\n");
                bw.flush();
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                bw.flush();
                bw.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    static boolean generateSkipAlternative(Rngs rngs, int streamIndex, long queueSize) {
        //select the appropriate stream
        rngs.selectStream(1 + streamIndex);

        //define the upper and lower bounds
        double upperBound = 13;
        double lowerBound = 0;

        //calculate the coefficient and the intercept
        double coefficient = 80 / (upperBound - lowerBound);
        double intercept = 80 - (80 * upperBound) / (upperBound - lowerBound);

        //calculate y using the linear formula
        double y = coefficient * queueSize + intercept;

        //calculate the skip probability as specified
        double percentage = y >= 0 ? Math.min(0.8, y / 100) : 0;

        //generate a random value and compare with the percentage
        return rngs.random() <= percentage;
    }



    //this function generate a true value with (percentage * 100) % probability, oth. false
    static boolean generateAbandon(Rngs rngs, int streamIndex, double percentage) {
        rngs.selectStream(1 + streamIndex);
        return rngs.random() <= percentage;
    }


    int findIdleDocCheckServer(MsqEvent[] events) {
        /* -----------------------------------------------------
         * return the index of the available server idle longest
         * -----------------------------------------------------
         */
        int s;

        int i = 1;

        while (events[i].x == 1)       /* find the index of the first available */
            i++;                        /* (idle) server                         */
        s = i;


        while (i < SERVERS_CAR_DOC) {         /* now, check the others to find which   */
            i++;                                     /* has been idle longest                 */
            if ((events[i].x == 0) && (events[i].t < events[s].t))
                s = i;
        }
        return (s);
    }

    int findIdleVehicleInspServer(MsqEvent[] events) {
        /* -----------------------------------------------------
         * return the index of the available server idle longest
         * -----------------------------------------------------
         */
        int s;

        int i = ALL_EVENTS_CAR_DOC + 1;

        while (events[i].x == 1)       /* find the index of the first available */
            i++;                      /* (idle) server                         */
        s = i;
        while (i < ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION) {         /* now, check the others to find which   */
            i++;                                             /* has been idle longest                 */
            if ((events[i].x == 0) && (events[i].t < events[s].t))
                s = i;
        }
        return (s);
    }


    double exponential(double m, Rngs r) {
        /* ---------------------------------------------------
         * generate an Exponential random variate, use m > 0.0
         * ---------------------------------------------------
         */
        return (-m * Math.log(1.0 - r.random()));
    }



    double getArrival(Rngs r, int streamIndex, double currentTime) {
        /* --------------------------------------------------------------
         * generate the next arrival time, exponential with rate given by the current time slot
         * --------------------------------------------------------------
         */
        r.selectStream(1 + streamIndex);

        int index = 0;  /* forcing the first time slot, for the verification step */

        sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / (3600*24)), r);

        return (sarrival);
    }

    double getService(Rngs r, int streamIndex, double serviceTime) {
        r.selectStream(1 + streamIndex);
        return (exponential(serviceTime, r));
    }


    int nextEvent(MsqEvent[] event) {
        /* ---------------------------------------
         * return the index of the next event type
         * ---------------------------------------
         */
        int e;
        int i = 0;

        while (event[i].x == 0)       /* find the index of the first 'active' */
            i++;                        /* element in the event list            */
        e = i;
        while (i < ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION  - 1) {         /* now, check the others to find which  */
            i++;                        /* event type is most imminent          */
            if ((event[i].x == 1) && (event[i].t < event[e].t))
                e = i;
        }
        return (e);
    }


}


