package org.example.infiniteHorizon;


import org.example.libraries.Rngs;
import org.example.utils.Estimate;
import org.example.utils.TimeSlot;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.example.utils.ConstantData.*;
import static org.example.utils.Events.*;
import static org.example.utils.NormalService.getServiceNormal;

public class PullmanInfiniteHorizon {


    /*
     *  Model:
     *  -----------> check ---------------->
     *                               |
     *                               | P1
     *                               V
     */




        static double START = 0.0;            /* initial (open the door)        */
        static double STOP = Double.POSITIVE_INFINITY;        /* terminal (close the door) time */
        static double sarrival = START;

        static List<TimeSlot> slotList = new ArrayList<>();

        public static void main(String[] args) {

            /* population counter*/
            long populationPullman = 0;


            int e;      /* next event index */
            int s;      /* server index */

            /* processed jobs counter */
            long indexPullman = 0;

            /* time integrated number*/
            double areaPullman = 0.0;

            double service;     /* it will contain the service times */

            /* abandons counter  */
            long abandonsCounterPullman = 0;


            /* abandons list  */
            List<Double> abandonsPullmanList = new ArrayList<>();
            /* first completion*/
            double pullmanCheckFirstCompletion = 0;

            PullmanInfiniteHorizon m = new PullmanInfiniteHorizon();
            Rngs r = new Rngs();
            r.plantSeeds(0);

            /* time slots initialization */
            for (int f = 0; f < 3; f++) {
                System.out.println(PERCENTAGE[f] + "; " + (int) (LAMBDA*pp) );
                TimeSlot slot = new TimeSlot(PERCENTAGE[f], (int) (LAMBDA*pp), 3600* 8 * f, 3600 * 8 * (f + 1) - 1);
                slotList.add(slot);
            }

            /* batch parameters */
            int k =512;
            int b = 1024*2;
            /* lists for batch simulation */

            /* waiting times */
            List<Double> delaysPullmanCheck = new ArrayList<>();

            /* response times */
            List<Double> responseTimesPullmanCheck = new ArrayList<>();
            List<Double> responseTimesPullmanCumulative= new ArrayList<>();
            /* utilizations */
            List<Double> utilizationsPullmanCheck = new ArrayList<>();

            /* system populations */
            List<Double> avgPopulationsPullmanCheck = new ArrayList<>();

            /* interarrivals */
            List<Double> interarrivalsPullmanCheck = new ArrayList<>();

            /* abandons */
            List<Double> allAbandonsPullmanCheck = new ArrayList<>();


            /* service times */
            List<Double> serviceTimesPullmanCheck = new ArrayList<>();


            double currentBatchStartingTime = 0;
            double currentFirstArrivalTimePullmanCheck = 0;

            long batchCounter = 0;

            /* events array initialization */
            org.example.infiniteHorizon.MsqEvent[] events = new org.example.infiniteHorizon.MsqEvent[ALL_EVENTS_PULLMAN];

            /* sum array initialization (to keep track of services) */
            org.example.infiniteHorizon.MsqSum[] sum = new org.example.infiniteHorizon.MsqSum[ALL_EVENTS_PULLMAN ];
            for (s = 0; s < ALL_EVENTS_PULLMAN; s++) {
                events[s] = new org.example.infiniteHorizon.MsqEvent();
                sum[s] = new org.example.infiniteHorizon.MsqSum();
            }

            /* clock initialization */
            org.example.infiniteHorizon.MsqT t = new org.example.infiniteHorizon.MsqT();
            t.current = START;

            /* generating the first arrival */
            events[0].t = m.getArrival(r,250 ,t.current);
            events[0].x = 1;

            /* all other servers are initially idle */
            for (s = 1; s < ALL_EVENTS_PULLMAN; s++) {
                events[s].t = START;
                events[s].x = 0;
                sum[s].service = 0.0;
                sum[s].served = 0;
            }

            /* START ITERATION */

            while ((events[0].x != 0)) {

                if (indexPullman != 0 && indexPullman %b == 0) {

                    /* new batch */
                    batchCounter++;


                    responseTimesPullmanCheck.add(areaPullman / indexPullman);
                    if (responseTimesPullmanCumulative.isEmpty()) {
                        // Se è il primo, la media cumulata è semplicemente il primo valore
                        responseTimesPullmanCumulative.add(responseTimesPullmanCheck.get(0));
                    } else {
                        // Altrimenti, somma l'ultimo valore cumulato e la nuova media
                        double previousCumulative = responseTimesPullmanCumulative.get(responseTimesPullmanCumulative.size() - 1);
                        double currentResponseTime = responseTimesPullmanCheck.get(responseTimesPullmanCheck.size() - 1);
                        double newCumulativeMean = (previousCumulative * (responseTimesPullmanCumulative.size()) + currentResponseTime) / (responseTimesPullmanCumulative.size() + 1);

                        responseTimesPullmanCumulative.add(newCumulativeMean);
                    }
                    interarrivalsPullmanCheck.add((events[ARRIVAL_EVENT_PULLMAN- 1].t - currentFirstArrivalTimePullmanCheck) / indexPullman);
                    allAbandonsPullmanCheck.add((double) abandonsCounterPullman / b);

                    double pullmanCheckActualTime = t.current - currentBatchStartingTime;

                    avgPopulationsPullmanCheck.add(areaPullman / pullmanCheckActualTime);

                    for (s = 1; s <= SERVERS_PULLMAN; s++)          /* adjust area to calculate */
                        areaPullman -= sum[s].service;                 /* averages for the queue   */

                    delaysPullmanCheck.add(areaPullman / indexPullman);

                    double sumUtilizations = 0.0;
                    double sumServices = 0.0;
                    double sumServed = 0.0;


                    for (s = 1; s <= SERVERS_PULLMAN; s++) {
                        sumUtilizations += sum[s].service / pullmanCheckActualTime;
                        sumServices += sum[s].service;
                        sumServed += sum[s].served;
                    }

                    utilizationsPullmanCheck.add(sumUtilizations / SERVERS_PULLMAN);
                    serviceTimesPullmanCheck.add(sumServices / sumServed);


                    areaPullman = 0;
                    indexPullman = 0;
                    abandonsCounterPullman = 0;

                    for (s = 1; s <= SERVERS_PULLMAN; s++) {
                        sum[s].served = 0;
                        sum[s].service = 0;
                    }


                    /* final updates */
                    currentBatchStartingTime = t.current;
                    currentFirstArrivalTimePullmanCheck = events[0].t;

                }

                if (batchCounter == k)
                    break;


                // abandons
                if (!abandonsPullmanList.isEmpty()) {
                    events[ALL_EVENTS_PULLMAN- 1].t = abandonsPullmanList.get(0);
                    events[ALL_EVENTS_PULLMAN - 1].x = 1;
                } else {
                    events[ALL_EVENTS_PULLMAN - 1].x = 0;
                }


                e = m.nextEvent(events);    /* next event index */
                t.next = events[e].t;       /* next event time */


                /* update integrals */
                areaPullman += (t.next - t.current) * populationPullman;
                t.current = t.next;     /* advance the clock */

                if (e == ARRIVAL_EVENT_PULLMAN - 1) {
                    /* process an arrival */

                    populationPullman++;

                    /* generate the next arrival */
                    events[ARRIVAL_EVENT_PULLMAN - 1].t = m.getArrival(r, 30 ,t.current);
                    if (events[ARRIVAL_EVENT_PULLMAN - 1].t > STOP)
                        events[ARRIVAL_EVENT_PULLMAN - 1].x = 0;

                    /* if there's no queue, put a job on service */
                    if (populationPullman <= SERVERS_PULLMAN) {
                      //  service = m.getService(r, 45, TS_PULLMAN);
                        service=getServiceNormal(r,240,45,10800,2400);
                        s = m.findIdlePullmanCheckServer(events);
                        sum[s].service += service;
                        sum[s].served++;
                        events[s].t = t.current + service;
                        events[s].x = 1;
                    }
                } else {
                    if (pullmanCheckFirstCompletion == 0)
                        pullmanCheckFirstCompletion = t.current;

                    indexPullman++;
                    populationPullman--;

                    /* generate an arrival */
                    events[ALL_EVENTS_PULLMAN-1].t = t.current;
                    events[ALL_EVENTS_PULLMAN-1].x = 1;

                    /* if there's queue, put a job in queue on service on this server */
                    s = e;
                    if (populationPullman >= SERVERS_PULLMAN) {
                    //    service = m.getService(r, 225, TS_PULLMAN);
                        service=getServiceNormal(r,240,225,10800,2400);

                        sum[s].service += service;
                        sum[s].served++;
                        events[s].t = t.current + service;
                    } else {
                        /* if there's no queue, deactivate this server */
                        events[s].x = 0;
                    }
                }

            }

            System.out.println("END OF ITERATION");


            /* BATCH SIMULATION RESULTS */

            System.out.println("Completed " + batchCounter + " batches");
            System.out.println();


            /* files creation for interval estimation */
            String directory = "batch_reports";

            /* DOCUMENT CHECK */
            writeFile(delaysPullmanCheck, directory, "delays_pullman_check");
            writeFile(responseTimesPullmanCheck, directory, "response_times_pullman_check");
            writeFile(utilizationsPullmanCheck, directory, "utilizations_pullman_check");
            writeFile(avgPopulationsPullmanCheck, directory, "populations_pullman_check");
            writeFile(interarrivalsPullmanCheck, directory, "interarrivals_pullman_check");
            writeFile(allAbandonsPullmanCheck, directory, "abandons_pullman_check");
            writeFile(serviceTimesPullmanCheck, directory, "service_times_pullman_check");
            writeFile(responseTimesPullmanCumulative, directory, "cumulative_response_times_pullman");

            /* INTERVAL ESTIMATION */

            Estimate estimate = new Estimate();
            List<String> filenames = List.of("response_times_pullman_check", "delays_pullman_check", "utilizations_pullman_check", "interarrivals_pullman_check", "abandons_pullman_check", "service_times_pullman_check", "populations_pullman_check"
                    );

            for (String filename : filenames) {
                estimate.createInterval(directory, filename);
            }

        }

        public static void writeFile(List<Double> list, String directoryName, String filename) {
            File directory = new File(directoryName);
            BufferedWriter bw = null;

            try {
                if (!directory.exists())
                    directory.mkdirs();

                File file = new File(directory, filename + ".dat");

                if (!file.exists())
                    file.createNewFile();

                FileWriter writer = new FileWriter(file);
                bw = new BufferedWriter(writer);


                for (int i = 0; i < list.size(); i++) {
                    bw.append(String.valueOf(list.get(i)));
                    bw.append("\n");
                    bw.flush();
                }

            } catch (IOException ex) {
                ex.printStackTrace();
            } finally {
                try {
                    bw.flush();
                    bw.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }



        // this function generate a true value with (percentage * 100) % probability, oth. false
        static boolean generateAbandon(Rngs rngs, int streamIndex, double percentage) {
            rngs.selectStream(1 + streamIndex);
            return rngs.random() <= percentage;
        }

        int findIdlePullmanCheckServer(org.example.infiniteHorizon.MsqEvent[] events) {
            /* -----------------------------------------------------
             * return the index of the available server idle longest
             * -----------------------------------------------------
             */
            int s;

            int i = 1;

            while (events[i].x == 1)       /* find the index of the first available */
                i++;                        /* (idle) server                         */
            s = i;


            while (i < SERVERS_PULLMAN) {         /* now, check the others to find which   */
                i++;                                     /* has been idle longest                 */
                if ((events[i].x == 0) && (events[i].t < events[s].t))
                    s = i;
            }
            return (s);
        }

        double exponential(double m, Rngs r) {
            /* ---------------------------------------------------
             * generate an Exponential random variate, use m > 0.0
             * ---------------------------------------------------
             */
            return (-m * Math.log(1.0 - r.random()));
        }

        double getArrival(Rngs r, int streamIndex, double currentTime) {
            /* --------------------------------------------------------------
             * generate the next arrival time, exponential with rate given by the current time slot
             * --------------------------------------------------------------
             */
            r.selectStream(1 + streamIndex);

            int index = 2;  /* forcing the first time slot, for the verification step */
            sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / (3600*24)), r);

            return (sarrival);
        }

        double getService(Rngs r, int streamIndex, double serviceTime) {
            r.selectStream(1 + streamIndex);
            return (exponential(serviceTime, r));
        }

        int nextEvent(org.example.infiniteHorizon.MsqEvent[] event) {
            /* ---------------------------------------
             * return the index of the next event type
             * ---------------------------------------
             */
            int e;
            int i = 0;

            while (event[i].x == 0)       /* find the index of the first 'active' */
                i++;                        /* element in the event list            */
            e = i;
            while (i < ALL_EVENTS_PULLMAN- 1) {         /* now, check the others to find which  */
                i++;                        /* event type is most imminent          */
                if ((event[i].x == 1) && (event[i].t < event[e].t))
                    e = i;
            }
            return (e);
        }


}



