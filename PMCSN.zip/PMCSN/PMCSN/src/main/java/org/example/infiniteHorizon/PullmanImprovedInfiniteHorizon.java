package org.example.infiniteHorizon;


import org.example.libraries.Rngs;
import org.example.utils.Estimate;
import org.example.utils.TimeSlot;

import java.util.ArrayList;
import java.util.List;

import static org.example.infiniteHorizon.PullmanInfiniteHorizon.writeFile;
import static org.example.utils.ConstantData.*;
import static org.example.utils.Events.*;
import static org.example.utils.NormalService.getServiceNormal;

public class PullmanImprovedInfiniteHorizon {
    static double START = 0.0;            /* initial (open the door)        */
    static double STOP = Double.POSITIVE_INFINITY;        /* terminal (close the door) time */
    static double sarrival = START;

    static List<TimeSlot> slotList = new ArrayList<>();

    public static void main(String[] args) throws Exception {

        /* batch simulation parameters */
        int k =1024*3;
        int b = 1024*8;

        /* lists to save batch data */
        List<Double> responseTimes = new ArrayList<>();
        List<Double> interarrivals = new ArrayList<>();
        List<Double> delays = new ArrayList<>();
        List<Double> populations = new ArrayList<>();
        List<Double> abandons = new ArrayList<>();
        List<Double> utilizations = new ArrayList<>();
        List<Double> serviceTimes = new ArrayList<>();

        int batchCounter = 0;
        double currentBatchStartingTime = 0;
        double currentFirstArrivalTime = 0;

        int streamIndex = 1;
        long classOneTotalPopulation = 0;
        long classTwoTotalPopulation = 0;
        long firstClassJobInQueue = 0;
        long secondClassJobInQueue = 0;
        int e;                      /* next event index*/
        int s;                      /* server index*/
        long indexServer = 0;            /* used to count processed jobs whole node*/
        long indexServerWait = 0;  /* used to count processed jobs*/


        double areaServer = 0.0;           /* time integrated number in the node */
        double areaServerWait = 0.0;
        double service;
        long abandonCheck = 0;
        List<Double> abandon = new ArrayList<>();
        double serverFirstCompletetion = 0;

        PullmanImprovedInfiniteHorizon m = new PullmanImprovedInfiniteHorizon();
        List<Integer> serverPriorityClassService = new ArrayList<>();

        for (int i = 0; i < SERVERS_PULLMAN; i++) {
            serverPriorityClassService.add(0);
        }

        Rngs r = new Rngs();
        r.plantSeeds(0);


        for (int f = 0; f < 3; f++) {
            TimeSlot slot = new TimeSlot(PERCENTAGE[f], (int) (LAMBDA*pp), 3600* 8 * f, 3600 * 8 * (f + 1) - 1);
            slotList.add(slot);
        }

        MsqEvent[] event = new MsqEvent[ALL_EVENTS_PULLMAN];
        MsqSum[] sum = new MsqSum[ALL_EVENTS_PULLMAN];

        for (s = 0; s < ALL_EVENTS_PULLMAN; s++) {
            event[s] = new MsqEvent();
            sum[s] = new MsqSum();
        }

        MsqT t = new MsqT();
        t.current = START;

        event[0].t = m.getArrival(r, 24, t.current);
        event[0].x = 1;

        for (s = 1; s < SERVERS_PULLMAN; s++) {
            event[s].t = START;          /* this value is arbitrary because */
            event[s].x = 0;              /* all servers are initially idle  */
            sum[s].service = 0.0;
            sum[s].served = 0;
        }

        while ((event[0].x != 0)) {

            if ((indexServer != 0) && (indexServer % b == 0)) {
                /* new batch */
                batchCounter++;

                responseTimes.add(areaServer / indexServer);
                interarrivals.add((event[ARRIVAL_EVENT_PULLMAN - 1].t - currentFirstArrivalTime) / indexServer);

                double actualTime = t.current - currentBatchStartingTime;

                populations.add(areaServer / actualTime);
                abandons.add((double) abandonCheck / b);

                for (s = 1; s <= SERVERS_PULLMAN; s++)          /* adjust area to calculate */
                    areaServer -= sum[s].service;              /* averages for the queue */

                delays.add(areaServer / indexServer);

                double allServices = 0;
                double allServed = 0;
                double sumUtilizations = 0;

                for (s = 1; s <= SERVERS_PULLMAN; s++) {
                    sumUtilizations += sum[s].service / actualTime;
                    allServices += sum[s].service;
                    allServed += sum[s].served;
                }

                utilizations.add(sumUtilizations / SERVERS_PULLMAN);
                serviceTimes.add(allServices / allServed);

                areaServer = 0;
                areaServerWait = 0;
                indexServer = 0;

                for (s = 1; s <= SERVERS_PULLMAN; s++) {
                    sum[s].service = 0;
                    sum[s].served = 0;
                }

                /* final updates */
                currentBatchStartingTime = t.current;
                currentFirstArrivalTime = event[ARRIVAL_EVENT_PULLMAN - 1].t;
            }

            if (batchCounter == k)
                break;

            if (!abandon.isEmpty()) {
                event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].t = abandon.get(0);
                event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].x = 1;     // activate abandon
            } else {
                event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].x = 0;     // deactivate abandon
            }

            e = m.nextEvent(event);                                         /* next event index */
            t.next = event[e].t;                                            /* next event time  */
            areaServer += (t.next - t.current) * (classOneTotalPopulation + classTwoTotalPopulation);  /* update integral  */
            areaServerWait += (t.next - t.current) * (firstClassJobInQueue + secondClassJobInQueue);
            t.current = t.next;                                             /* advance the clock*/

            if (e == ARRIVAL_EVENT_PULLMAN - 1) {
                /* pullman arrival */

                event[0].t = m.getArrival(r, 48, t.current);    // generate next arrival
                if (event[0].t > STOP)
                    event[0].x = 0;
            //    service=getServiceNormal(r,240,45,10800,2400);

                service = m.getService(r, 96, TS_PULLMAN);
                if (service < 2400) {
                    /* first queue */
                    classOneTotalPopulation++;
                } else {
                    /* second queue */
                    classTwoTotalPopulation++;
                }
                if (classOneTotalPopulation + classTwoTotalPopulation <= SERVERS_PULLMAN) {
                    /* the total node population is below the total number of servers */
                    s = m.findServer(event);

                    /* mark s as service for the first/second queue */
                    // bind server index with job type into the array
                    if (service < 2400) {
                        try {
                            // small job ( without bags)
                            serverPriorityClassService.set(s - 1, 1);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    } else {
                        try {
                            // big job
                            serverPriorityClassService.set(s - 1, 2);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }

                    sum[s].service += service;
                    sum[s].served++;
                    event[s].t = t.current + service;
                    event[s].x = 1;
                } else {
                    //UPDATE THE NUMBER OF JOBS IN QUEUE
                    indexServerWait++;

                    if (service < 2400)
                        firstClassJobInQueue++;
                    else secondClassJobInQueue++;
                }

            } else if (e == SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN) {

                abandonCheck++;
                abandon.remove(0);

            } else if ((e >= ARRIVAL_EVENT_PULLMAN) && (e <= SERVERS_PULLMAN)) {

                boolean isFromFirstQueue = (serverPriorityClassService.get(e - 1) == 1);
                if (isFromFirstQueue)
                    classOneTotalPopulation--;
                else
                    classTwoTotalPopulation--;

                // service
                if (serverFirstCompletetion == 0)
                    serverFirstCompletetion = t.current;

                /* update number of completed jobs */
                indexServer++;

                boolean isAbandon = generateAbandon(r, 120, P1);
                if (isAbandon) {
                    double abandonTime = t.current + 0.01;
                    abandon.add(abandonTime);
                }


                s = e;
                // Now, there is idle server, so re-generate service time for queued job
                if (firstClassJobInQueue >= 1) {
                    firstClassJobInQueue--;
                    // GENERATE A SERVICE LESS THAN 10 SECONDS
                    do {
                       service = m.getService(r, 144, TS_PULLMAN);
                  //      service=getServiceNormal(r,240,144,10800,2400);

                    } while (!(service < 2400));
                    serverPriorityClassService.set(s - 1, 1);
                    sum[s].service += service;
                    sum[s].served++;
                    event[s].t = t.current + service;
                    event[s].x = 1;
                } else if (secondClassJobInQueue >= 1) {
                    secondClassJobInQueue--;
                    // GENERATE A SERVICE GREATER THEN 2400 SECONDS
                    do {
                        service = m.getService(r, 168, TS_PULLMAN);
                        //service=getServiceNormal(r,240,168,10800,2400);

                    } while ((service < 2400));
                    serverPriorityClassService.set(s - 1, 2);
                    sum[s].service += service;
                    sum[s].served++;
                    event[s].t = t.current + service;
                    event[s].x = 1;
                } else
                    event[s].x = 0;
            } else {
                throw new Exception("Unexpected behaviour!");
            }
        }

        /* BATCH SIMULATION RESULTS */

        System.out.println("Completed " + batchCounter + " batches");

        System.out.println("");


        /* files creation for interval estimation */
        String directory = "improved_model_batch_reports";

        writeFile(responseTimes, directory, "pullman_response_times");

        writeFile(interarrivals, directory, "pullman_interarrivals");

        writeFile(delays, directory, "pullman_delays");

        writeFile(populations, directory, "pullman_populations");

        writeFile(abandons, directory, "pullman_abandons");

        writeFile(utilizations, directory, "pullman_utilizations");

        writeFile(serviceTimes, directory, "pullman_service_times");

        /* INTERVAL ESTIMATION */

        Estimate estimate = new Estimate();
        List<String> filenames = List.of("pullman_response_times", "pullman_interarrivals", "pullman_delays", "pullman_populations", "pullman_abandons", "pullman_utilizations", "pullman_service_times");

        for(String filename :filenames) {
            estimate.createInterval(directory, filename);
        }


    }

    // this function generate a true value with (percentage * 100) % probability, oth. false
    static boolean generateAbandon(Rngs rngs, int streamIndex, double percentage) {
        rngs.selectStream(1 + streamIndex);
        return rngs.random() <= percentage;
    }


    double exponential(double m, Rngs r) {
        /* ---------------------------------------------------
         * generate an Exponential random variate, use m > 0.0
         * ---------------------------------------------------
         */
        return (-m * Math.log(1.0 - r.random()));
    }


    double getArrival(Rngs r, int streamIndex, double currentTime) {
        /* --------------------------------------------------------------
         * generate the next arrival time, exponential with rate given by the current time slot
         * --------------------------------------------------------------
         */
        r.selectStream(1 + streamIndex);

        int index = 2 ;  // verification step (forcing the first timeslot)

        sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / (3600*24)), r);
        return (sarrival);
    }


    double getService(Rngs r, int streamIndex, double serviceTime) {
        r.selectStream(1 + streamIndex);
        return (exponential(serviceTime, r));
    }

    int nextEvent(MsqEvent[] event) {
        /* ---------------------------------------
         * return the index of the next event type
         * ---------------------------------------
         */
        int e;
        int i = 0;

        while (event[i].x == 0)       /* find the index of the first 'active' */
            i++;                        /* element in the event list            */
        e = i;
        while (i < ALL_EVENTS_PULLMAN - 1) {         /* now, check the others to find which  */
            i++;                        /* event type is most imminent          */
            if ((event[i].x == 1) && (event[i].t < event[e].t))
                e = i;
        }
        return (e);
    }


    int findServer(MsqEvent[] event) {
        /* -----------------------------------------------------
         * return the index of the available server idle longest
         * -----------------------------------------------------
         */
        int s;

        int i = 0;

        while (event[i].x == 1)       /* find the index of the first available */
            i++;                        /* (idle) server                         */
        s = i;
        while (i < SERVERS_PULLMAN) {         /* now, check the others to find which   */
            i++;                                             /* has been idle longest                 */
            if ((event[i].x == 0) && (event[i].t < event[s].t))
                s = i;
        }
        return (s);
    }
}
