package org.example.utils;

public class ConstantData {


        // ---- PULLMAN PROB ----
        public static final  double pp = 0.1;
        //auto
        public static final double pa=0.89;
        //CD
        public static final double pc=0.01;
        // ---- PULLMAN ABANDON PROB ----
        // probability of abandon for pullmans
        public static final double P1 = 0.0002;

        // probability of abandon after cars' documents check
        public static final double P2 = 0.001;

        // probability of abandon after vehicle inspection
        public static final double P3 = 0.002;


        public static double[] PERCENTAGE={0.05, 0.75, 0.2};


        //VEHICLES

        public static final double LAMBDA = 4880;



        // ---- SERVICE RATES  [sec] ----

        public static final double TS_PULLMAN =2400; //sec


        public static final double TS_DOC_CARS = 180 ;//sec

        public static final double TS_VEHICLE_INSPECTION_CARS = 360; //sec

        public static final double TS_CD = 120;



}
