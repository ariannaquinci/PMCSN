package org.example.libraries;

public class MsqEvent {                     /* the next-event list    */
    public double t;                         /*   next event time      */
    public int x;                         /*   event status, 0 or 1 */
}
