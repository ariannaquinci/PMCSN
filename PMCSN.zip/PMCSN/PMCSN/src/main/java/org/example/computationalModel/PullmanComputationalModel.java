package org.example.computationalModel;

import org.example.libraries.Rngs;
import org.example.utils.Estimate;
import org.example.utils.TimeSlot;
import org.example.utils.TimeSlotController;

import java.util.ArrayList;
import java.util.List;

import static org.example.infiniteHorizon.VehicleInfiniteHorizon.writeFile;
import static org.example.utils.ConstantData.*;
import static org.example.utils.ConstantData.TS_PULLMAN;
import static org.example.utils.Events.*;
import static org.example.utils.Events.SERVERS_PULLMAN;

public class PullmanComputationalModel {



        static List<Double> responseTimes = new ArrayList<>();
        static List<Double> interarrivals = new ArrayList<>();
        static List<Double> delays = new ArrayList<>();
        static List<Double> avgPopulations = new ArrayList<>();
        static List<Double> allAbandons = new ArrayList<>();
        static List<Double> utilizations = new ArrayList<>();
        static List<Double> serviceTimes = new ArrayList<>();
        static List<Double> indexes = new ArrayList<>();


        static final double START = 0.0;            /* initial (open the door)        */
        static final double STOP = 24 * 3600;        /* terminal (close the door) time */
        static double sarrival = START;

        static List<TimeSlot> slotList = new ArrayList<>();

        static long simulation(long seed, Rngs r) throws Exception {
            sarrival = START;
            int streamIndex = 1;
            long numberPullman = 0;   /* number in the node    */

            int e;                      /* next event index                    */
            int s;                      /* server index                        */

            long indexPullman = 0;             /* used to count processed jobs  */
            double areaPullman = 0.0;           /* time integrated number in the node */

            double service;
            long abandonPullman = 0;
            List<Double> abandonsPullman = new ArrayList<>();

            double firstCompletionPullman = 0;

            r.plantSeeds(seed);


            for (int f = 0; f < 3; f++) {
                TimeSlot slot = new TimeSlot(PERCENTAGE[f], (int) (LAMBDA*pp), 3600*8 * f, 3600*8 * (f + 1) - 1);
                slotList.add(slot);
            }

            MsqEvent[] event = new MsqEvent[ALL_EVENTS_PULLMAN];
            MsqSum[] sum = new MsqSum[ALL_EVENTS_PULLMAN];
            for (s = 0; s < ALL_EVENTS_PULLMAN; s++) {
                event[s] = new MsqEvent();
                sum[s] = new MsqSum();
            }

            MsqT t = new MsqT();
            t.current = START;

            event[0].t = getArrival(r, t.current);
            event[0].x = 1;

            for (s = 1; s < ALL_EVENTS_PULLMAN; s++) {
                event[s].t = START;          /* this value is arbitrary because */
                event[s].x = 0;              /* all servers are initially idle  */
                sum[s].service = 0.0;
                sum[s].served = 0;
            }



                if (!abandonsPullman.isEmpty()) {
                    event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].t = abandonsPullman.get(0);
                    event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].x = 1;     // activate abandon
                } else {
                    event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].x = 0;     // deactivate abandon
                }


                e = nextEvent(event);                                         /* next event index */
                t.next = event[e].t;                                            /* next event time  */
                areaPullman += (t.next - t.current) * numberPullman;    /* update integral  */
                t.current = t.next;                                             /* advance the clock*/

                if (e == ARRIVAL_EVENT_PULLMAN - 1) {     /* process an arrival */

                    numberPullman++;

                    event[0].t = getArrival(r, t.current);
                    if (event[0].t > STOP)
                        event[0].x = 0;

                    if (numberPullman <= SERVERS_PULLMAN) {
                        service = getService(r, TS_PULLMAN);
                        s = findServer(event);
                        sum[s].service += service;
                        sum[s].served++;
                        event[s].t = t.current + service;
                        event[s].x = 1;
                    }
                } else if (e == SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN) {    // process an abandon
                    abandonPullman++;
                    abandonsPullman.remove(0);
                } else {
                    /* departure from node */
                    if (firstCompletionPullman == 0)
                        firstCompletionPullman = t.current;

                    //event[ALL_EVENTS_PULLMAN-1].x = 0;

                    boolean abandon = generateAbandon(r, streamIndex, P1);
                    if (abandon) {
                        double abandonTime = t.current + 0.01;
                        abandonsPullman.add(abandonTime);
                    } else {
                        indexPullman++;
                        numberPullman--;
                        //event[ALL_EVENTS_PULLMAN-1].t = t.current;
                        //event[ALL_EVENTS_PULLMAN-1].x = 1;

                        s = e;
                        if (numberPullman >= SERVERS_PULLMAN) {     // there are jobs in queue
                            service = getService(r, TS_PULLMAN);
                            sum[s].service += service;
                            sum[s].served++;
                            event[s].t = t.current + service;
                        } else
                            event[s].x = 0;
                    }
                }



            /* SAVE STATISTICS */

            /* DOCUMENT CHECK */
            responseTimes.add(areaPullman / indexPullman);
            interarrivals.add((event[0].t) / indexPullman);
            allAbandons.add((double) abandonPullman);

            double finalTimeTC = 0;
            for (s = 1; s <= SERVERS_PULLMAN; s++) {
                if (event[s].t > finalTimeTC)
                    finalTimeTC = event[s].t;
            }

            double actualTimeTC = finalTimeTC - firstCompletionPullman;

            avgPopulations.add(areaPullman / actualTimeTC);

            for (s = 1; s <= SERVERS_PULLMAN; s++)          /* adjust area to calculate */
                areaPullman -= sum[s].service;                 /* averages for the queue   */

            delays.add(areaPullman / indexPullman);

            double sumUtilizations = 0.0;
            double sumServices = 0.0;
            double sumServed = 0.0;


            for (s = 1; s <= SERVERS_PULLMAN; s++) {
                sumUtilizations += sum[s].service / actualTimeTC;
                sumServices += sum[s].service;
                sumServed += sum[s].served;
            }

            utilizations.add(sumUtilizations / SERVERS_PULLMAN);
            serviceTimes.add(sumServices / sumServed);
            indexes.add((double)indexPullman);



            r.selectStream(255);
            return r.getSeed();
        }

        static boolean generateAbandon(Rngs rngs, int streamIndex, double percentage) {
            rngs.selectStream(1 + streamIndex);
            return rngs.random() <= percentage;
        }


        static double exponential(double m, Rngs r) {
            /* ---------------------------------------------------
             * generate an Exponential random variate, use m > 0.0
             * ---------------------------------------------------
             */
            return (-m * Math.log(1.0 - r.random()));
        }

        static double getArrival(Rngs r, double currentTime) {
            /* --------------------------------------------------------------
             * generate the next arrival time, exponential with rate given by the current time slot
             * --------------------------------------------------------------
             */
            r.selectStream(0);

            int index = TimeSlotController.timeSlotSwitch(slotList, currentTime);

            sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / (3600*24)), r);
            return (sarrival);
        }


        static double getService(Rngs r, double serviceTime) {
            r.selectStream(3);
            return (exponential(serviceTime, r));
        }

        static int nextEvent(MsqEvent[] event) {
            /* ---------------------------------------
             * return the index of the next event type
             * ---------------------------------------
             */
            int e;
            int i = 0;

            while (event[i].x == 0)       /* find the index of the first 'active' */
                i++;                        /* element in the event list            */
            e = i;
            while (i < ALL_EVENTS_PULLMAN - 1) {         /* now, check the others to find which  */
                i++;                        /* event type is most imminent          */
                if ((event[i].x == 1) && (event[i].t < event[e].t))
                    e = i;
            }
            return (e);
        }

        static int findServer(MsqEvent[] event) {
            /* -----------------------------------------------------
             * return the index of the available server idle longest
             * -----------------------------------------------------
             */
            int s;

            int i = 1;

            while (event[i].x == 1)       /* find the index of the first available */
                i++;                        /* (idle) server                         */
            s = i;
            while (i < SERVERS_PULLMAN) {         /* now, check the others to find which   */
                i++;                                             /* has been idle longest                 */
                if ((event[i].x == 0) && (event[i].t < event[s].t))
                    s = i;
            }
            return (s);
        }

        public static void main(String[] args) throws Exception {
            long[] seeds = new long[1024];
            seeds[0] = 123456789;
            Rngs r = new Rngs();
            for (int i = 0; i < 150; i++) {
                seeds[i + 1] = simulation(seeds[i], r);
                System.out.println(i+1);
            }

            /* files creation for interval estimation */
            String directory = "replication_reports";


            System.out.println("pullmanDelays: " + delays);
            System.out.println("pullmanRTs: " +responseTimes);
            System.out.println("pullmanUtilizations: " + utilizations);
            System.out.println("docCheckPopulations: " + avgPopulations);
            System.out.println("docCheckInterarrivals: " +interarrivals);
            System.out.println("docCheckSTs: " + serviceTimes);
            System.out.println("docCheckIndexes: " +indexes);
            writeFile(indexes, directory, "indexes_pullman");

            /* INTERVAL ESTIMATION */

            Estimate estimate = new Estimate();

            List<String> filenames = List.of("response_times_pullman", "delays_pullman", "utilizations_pullman", "interarrivals_pullman", "abandons_pullman", "service_times_pullman", "populations_pullman", "indexes_pullman"

            );

            for (String filename : filenames) {
                estimate.createInterval(directory, filename);
            }
        }
    }


