package org.example.libraries;

import org.example.utils.TimeSlot;
import org.example.utils.TimeSlotController;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import static org.example.utils.ConstantData.*;

import static org.example.utils.Events.*;

/*
-DOCUMENTS CHECK-
0 = ARRIVO
1-4 = SERVIZIO
5 = ABBANDONO

-VEHICLE INSPECTION-
6 = ARRIVO
7-10 = SERVIZIO
11 = SKIP
12 = ABBANDONO

*/


class Msq {

    static double START = 0.0;            /* initial (open the door)        */
    static double STOP = 3 * 3600;        /* terminal (close the door) time */
    static double sarrival = START;

    static List<TimeSlot> slotList = new ArrayList<>();

    public static void main(String[] args) {
        /* stream index for the rng */
        int streamIndex = 1;

        /* population counter for every node */
        long numberCarsDoc = 0;
        long numberVehicleInspect = 0;


        int e;      /* next event index */
        int s;      /* server index */

        /* processed jobs counter for every node */
        long indexCarsDoc = 0;
        long indexVehicleInspect = 0;


        /* time integrated number for every node */
        double areaCarsDoc = 0.0;
        double areaVehicleInspect = 0.0;


        double service;     /* it will contain the service times */

        /* abandons counter for documents and inspection */

        long abandonsDocCheck = 0;
        long abandonsVehicleInspect = 0;
        /*abandons list for documents and inspection */
        List<Double> abandonsListDocCheck = new ArrayList<>();
        List<Double> abandonsListVehicleInspect = new ArrayList<>();

        List<Double> skipListVehicleInspect = new ArrayList<>();


        long skipCounterVehicleInspect = 0;

        /* first completion for every node */
        double docCheckFirstCompletion = 0;
        double vehicleInspectFirstCompletion = 0;

        Msq m = new Msq();
        Rngs r = new Rngs();
        r.plantSeeds(0);

        /* time slots initialization */

        for (int f = 0; f < 3; f++) {
            TimeSlot slot = new TimeSlot(PERCENTAGE[f], 6000, 3600 * f, 3600 * (f + 1) - 1);
            slotList.add(slot);
        }

        /* events array initialization */
        MsqEvent[] events = new MsqEvent[
                ALL_EVENTS_CAR_DOC +
                        ALL_EVENTS_VEHICLE_INSPECTION
                ];


        /* sum array initialization (to keep track of services) */
        MsqSum[] sum = new MsqSum[ ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION];
        for (s = 0; s <  ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION; s++) {
            events[s] = new MsqEvent();
            sum[s] = new MsqSum();
        }

        /* clock initialization */
        MsqT t = new MsqT();
        t.current = START;

        /* generating the first arrival */
        events[0].t = m.getArrival(r, 17,t.current);
        events[0].x = 1;

        /* all other servers are initially idle */
        for (s = 1; s <  ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION; s++) {
            events[s].t = START;
            events[s].x = 0;
            sum[s].service = 0.0;
            sum[s].served = 0;
        }



        /* START ITERATION */

        while ((events[0].x != 0) || (numberCarsDoc + numberVehicleInspect!= 0)) {

            /* skip */
            if (!skipListVehicleInspect.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC+ALL_EVENTS_VEHICLE_INSPECTION - 2].t = skipListVehicleInspect.get(0);
                events[ALL_EVENTS_CAR_DOC+ALL_EVENTS_VEHICLE_INSPECTION - 2].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC+ALL_EVENTS_VEHICLE_INSPECTION - 2].x = 0;
            }

            /* abandons */
            if (!abandonsListDocCheck.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC - 1].t = abandonsListDocCheck.get(0);
                events[ALL_EVENTS_CAR_DOC - 1].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC - 1].x = 0;
            }

            if (!abandonsListVehicleInspect.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC+ ALL_EVENTS_VEHICLE_INSPECTION - 1].t = t.current;
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1].x = 0;
            }


            e = m.nextEvent(events);    /* next event index */
            t.next = events[e].t;       /* next event time */


            /* update integrals */
            areaCarsDoc += (t.next - t.current) * numberCarsDoc;
            areaVehicleInspect += (t.next - t.current) * numberVehicleInspect;

            t.current = t.next;     /* advance the clock */

            if (e == ARRIVAL_EVENT_CAR_DOC - 1) {    /* process an arrival TO DOCUMENTS CHECK */
                numberCarsDoc++;

                /* generate the next arrival */
                events[ARRIVAL_EVENT_CAR_DOC - 1].t = m.getArrival(r, 34,t.current);
                if (events[ARRIVAL_EVENT_CAR_DOC - 1].t > STOP)
                    events[ARRIVAL_EVENT_CAR_DOC - 1].x = 0;

                /* if there's no queue, put a job on service */
                if (numberCarsDoc <= SERVERS_CAR_DOC) {
                    service = m.getService(r, 51, TS_DOC_CARS);
                    s = m.findOneCarsDoc(events);
                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                    events[s].x = 1;
                }
            } else if (e == ALL_EVENTS_CAR_DOC - 1) {      /* process an abandon (following the documents' check) */

                abandonsDocCheck++;
                abandonsListDocCheck.remove(0);

            } else if (e == ALL_EVENTS_CAR_DOC) {      /* arrival at vehicle inspection */

                events[ALL_EVENTS_CAR_DOC].x = 0;

                /* generate an abandon with probability P1 */
                boolean abandon = generateAbandon(r, 68, P2);

                if (abandon) {
                    /* an abandon must be generated -> we must add it to the abandons list and schedule it */
                    double abandonTime = t.current + 0.01;
                    abandonsListDocCheck.add(abandonTime);

                } else {
                    /* no abandon -> arrival at vehicle inspection */

                    numberVehicleInspect++;
                    if (numberVehicleInspect <= SERVERS_VEHICLE_INSPECTION) {
                        service = m.getService(r, 85, TS_VEHICLE_INSPECTION_CARS);
                        s = m.findOneVehicleInspection(events);
                        sum[s].service += service;
                        sum[s].served++;
                        events[s].t = t.current + service;
                        events[s].x = 1;
                    }
                }
            } else if ((e > ALL_EVENTS_CAR_DOC) && (e <= ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION)) {

                /* skip vehicle inspection with probability x %, depending on the number of people in queue */
                boolean skip = generateSkip(r, 102, numberVehicleInspect - SERVERS_VEHICLE_INSPECTION);


                if (skip) {

                    double skipTime = t.current + 0.01;
                    skipListVehicleInspect.add(skipTime);

                } else {

                    if (vehicleInspectFirstCompletion == 0)
                        vehicleInspectFirstCompletion = t.current;

                    indexVehicleInspect++;
                    numberVehicleInspect--;

                    /* generate an abandon with probability P2 */
                    boolean abandon = generateAbandon(r, 119, P3);
                    if (abandon) {

                        /* an abandon must be generated -> we must add it to the abandons list and schedule it */
                        double abandonTime = t.current + 0.01;
                        abandonsListVehicleInspect.add(abandonTime);

                    } else {

                        events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION-1].t = t.current;
                        events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION-1].x = 1;
                    }
                }

                /* if there's queue, put a job on service on this server */
                s = e;
                if (numberVehicleInspect >= SERVERS_VEHICLE_INSPECTION) {
                    service = m.getService(r, 136, TS_VEHICLE_INSPECTION_CARS);
                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                } else {
                    /* if there's no queue, deactivate this server */
                    events[s].x = 0;

                }

            } else if (e == ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 2) {    /* skip vehicle inspection */
                indexVehicleInspect++;
                numberVehicleInspect--;
                skipCounterVehicleInspect++;
                skipListVehicleInspect.remove(0);



            } else if (e == ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1) {    /* abandon after vehicle inspection */

                abandonsVehicleInspect++;
                abandonsListVehicleInspect.remove(0);



            } else {    /* check first completion */
                if (docCheckFirstCompletion == 0)
                    docCheckFirstCompletion = t.current;

                indexCarsDoc++;
                numberCarsDoc--;

                events[ALL_EVENTS_CAR_DOC].t = t.current;
                events[ALL_EVENTS_CAR_DOC].x = 1;

                /* if there's queue, put a job in queue on service on this server */
                s = e;
                if (numberCarsDoc >= SERVERS_CAR_DOC) {
                    service = m.getService(r, 255,TS_DOC_CARS );
                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                } else {
                    /* if there's no queue, deactivate this server */
                    events[s].x = 0;
                }
            }

        }

        System.out.println("END OF ITERATION");

        /* the code below prints the simulation's statistics, for every node */

        DecimalFormat f = new DecimalFormat("###0.0000");
        DecimalFormat g = new DecimalFormat("###0.000000");




        System.out.println("\nfor " + indexCarsDoc + " jobs the document check statistics are:\n");
        System.out.println("  avg interarrivals .. =   " + f.format(events[ARRIVAL_EVENT_CAR_DOC - 1].t / indexCarsDoc));
        System.out.println("  avg response time .. =   " + f.format(areaCarsDoc / indexCarsDoc));

        double carsDocFinalTime = 0;
        double carsDocCheckMean = 0;
        for (s = 1; s <= SERVERS_CAR_DOC; s++) {
            carsDocCheckMean += events[s].t;
            if (events[s].t > carsDocFinalTime)
                carsDocFinalTime = events[s].t;
        }

        double docCheckActualTime = carsDocFinalTime - docCheckFirstCompletion;

        System.out.println("  avg # in node ...... =   " + f.format(areaCarsDoc / docCheckActualTime));

        System.out.println("# abandons: " + abandonsDocCheck);

        for (s = 1; s <= SERVERS_CAR_DOC; s++)          /* adjust area to calculate */
            areaCarsDoc -= sum[s].service;                 /* averages for the queue   */

        System.out.println("  avg delay .......... =   " + f.format(areaCarsDoc / indexCarsDoc));
        System.out.println("  avg # in queue ..... =   " + f.format(areaCarsDoc / docCheckActualTime));

        double sumUtilizations = 0.0;
        double sumServices = 0.0;
        double sumServed = 0.0;

        System.out.println("\nthe server statistics are:\n");
        System.out.println("    server     utilization     avg service      share");
        for (s = 1; s <= SERVERS_CAR_DOC; s++) {
            sumUtilizations += sum[s].service / docCheckActualTime;
            sumServices += sum[s].service;
            sumServed += sum[s].served;
            System.out.print("       " + (s) + "          " + g.format(sum[s].service / docCheckActualTime) + "            ");
            System.out.println(f.format(sum[s].service / sum[s].served) + "         " + g.format(sum[s].served / (double) indexCarsDoc));
        }

        System.out.println("Mean utilization: " + g.format(sumUtilizations / SERVERS_CAR_DOC));
        System.out.println("Avg service time = " + g.format(sumServices / sumServed));

        System.out.println("");


        /*VEHICLE INSPECTION*/


        System.out.println("  avg interarrivals .. =   " + f.format(events[ALL_EVENTS_CAR_DOC].t / indexVehicleInspect));
        System.out.println("  avg response time ........... =   " + f.format(areaVehicleInspect / indexVehicleInspect));

        double vehicleInspectFinalTime = 0;
        double vehicleInspectMean = 0;
        for (s = ALL_EVENTS_CAR_DOC + 1; s <= ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION; s++) {
            vehicleInspectMean += events[s].t;
            if (events[s].t > vehicleInspectFinalTime)
                vehicleInspectFinalTime = events[s].t;
        }

        double vehicleInspectActualTime = vehicleInspectFinalTime - vehicleInspectFirstCompletion;

        System.out.println("  avg # in node ...... =   " + f.format(areaVehicleInspect / vehicleInspectActualTime));

        System.out.println("# abandons: " + abandonsVehicleInspect);
        System.out.println("# skips: " + skipCounterVehicleInspect);

        for (s = ALL_EVENTS_CAR_DOC + 1; s <= ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION; s++)          /* adjust area to calculate */
            areaVehicleInspect -= sum[s].service;                                                                     /* averages for the queue   */


        System.out.println("  avg delay .......... =   " + f.format(areaVehicleInspect / indexVehicleInspect));
        System.out.println("  avg # in queue ..... =   " + f.format(areaVehicleInspect / vehicleInspectActualTime));

        sumUtilizations = 0.0;
        sumServices = 0.0;
        sumServed = 0.0;

        System.out.println("\nthe server statistics are:\n");
        System.out.println("    server     utilization     avg service      share");
        for (s = ALL_EVENTS_CAR_DOC + 1; s <= ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION; s++) {
            System.out.print("       " + (s - ALL_EVENTS_CAR_DOC) + "          " + g.format(sum[s].service / vehicleInspectActualTime) + "            ");
            System.out.println(f.format(sum[s].service / sum[s].served) + "         " + g.format(sum[s].served / (double) indexVehicleInspect));
            sumUtilizations += sum[s].service / vehicleInspectActualTime;
            sumServices += sum[s].service;
            sumServed += sum[s].served;
        }
        System.out.println("avg utilization = " + g.format(sumUtilizations / SERVERS_VEHICLE_INSPECTION));
        System.out.println("avg service = " + g.format(sumServices / sumServed));

        System.out.println("");

    }


    static boolean generateSkip(Rngs rngs, int streamIndex, long queueSize) {
        rngs.selectStream(1 + streamIndex);
        //va modificata in funzione dei nostri risultati su orizzonte finito
        double percentage = Math.min(0.8, (0.444444 * queueSize - 291.555555)/100);
        return rngs.random() <= percentage;
    }


    // this function generate a true value with (percentage * 100) % probability, oth. false
    static boolean generateAbandon(Rngs rngs, int streamIndex, double percentage) {
        rngs.selectStream(1 + streamIndex);
        return rngs.random() <= percentage;
    }


    int findOneCarsDoc(MsqEvent[] events) {
        /* -----------------------------------------------------
         * return the index of the available server idle longest
         * -----------------------------------------------------
         */
        int s;

        int i = 1;

        while (events[i].x == 1)       /* find the index of the first available */
            i++;                        /* (idle) server                         */
        s = i;


        while (i < SERVERS_CAR_DOC) {         /* now, check the others to find which   */
            i++;                                     /* has been idle longest                 */
            if ((events[i].x == 0) && (events[i].t < events[s].t))
                s = i;
        }
        return (s);
    }

    int findOneVehicleInspection(MsqEvent[] events) {
        /* -----------------------------------------------------
         * return the index of the available server idle longest
         * -----------------------------------------------------
         */
        int s;

        int i = ALL_EVENTS_CAR_DOC + 1;

        while (events[i].x == 1)       /* find the index of the first available */
            i++;                      /* (idle) server                         */
        s = i;
        while (i < ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION) {         /* now, check the others to find which   */
            i++;                                             /* has been idle longest                 */
            if ((events[i].x == 0) && (events[i].t < events[s].t))
                s = i;
        }
        return (s);
    }



    double exponential(double m, Rngs r) {
        /* ---------------------------------------------------
         * generate an Exponential random variate, use m > 0.0
         * ---------------------------------------------------
         */
        return (-m * Math.log(1.0 - r.random()));
    }

    double getArrival(Rngs r, int streamIndex, double currentTime) {
        /* --------------------------------------------------------------
         * generate the next arrival time, exponential with rate given by the current time slot
         * --------------------------------------------------------------
         */
        r.selectStream(1 + streamIndex);

        int index = TimeSlotController.timeSlotSwitch(slotList, currentTime);

        sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / 3600), r);
        // sarrival += exponential(1 / LAMBDA1, r);

        return (sarrival);
    }

    double getService(Rngs r, int streamIndex, double serviceTime) {
        r.selectStream(1 + streamIndex);
        return (exponential(serviceTime, r));
    }

    int nextEvent(MsqEvent[] event) {
        /* ---------------------------------------
         * return the index of the next event type
         * ---------------------------------------
         */
        int e;
        int i = 0;

        while (event[i].x == 0)       /* find the index of the first 'active' */
            i++;                        /* element in the event list            */
        e = i;
        while (i < ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1) {         /* now, check the others to find which  */
            i++;                        /* event type is most imminent          */
            if ((event[i].x == 1) && (event[i].t < event[e].t))
                e = i;
        }
        return (e);
    }


}


