package org.example.libraries;

public class MsqSum {                      /* accumulated sums of                */
    public double service;                   /*   service times                    */
    public long served;                    /*   number served                    */
}
