package org.example.computationalModel;
import org.example.libraries.Rngs;
import org.example.utils.TimeSlot;
import org.example.utils.TimeSlotController;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import static org.example.utils.ConstantData.*;


class CDSsq3Area {
    double node;                    /* time integrated number in the node  */
    double queue;                   /* time integrated number in the queue */
    double service;                 /* time integrated number in service   */

    void initAreaParas() {
        node = 0.0;
        queue = 0.0;
        service = 0.0;
    }
}

class CDSsq3T {
    double arrival;                 /* next arrival time                   */
    double completion;              /* next completion time                */
    double current;                 /* current time                        */
    double next;                    /* next (most imminent) event time     */
    double last;                    /* last arrival time                   */
}


public class CDComputationalModel {

    static double START = 0.0;              /* initial time                   */
    static double STOP  = 24*3600;          /* terminal (close the door) time */
    static double INFINITY = STOP;  /* must be much larger than STOP  */

    static double sarrival = START;              /* Why did I do this?       */

    static List<TimeSlot> slotList = new ArrayList<>();

    public static void main(String[] args) {

        long index  = 0;                  /* used to count departed jobs         */
        long number = 0;                  /* number in the node                  */

        CDComputationalModel s = new CDComputationalModel();

        Rngs r = new Rngs();
        r.plantSeeds(123456789);

        for (int f = 0; f < 3; f++) {

            TimeSlot slot = new TimeSlot(PERCENTAGE[f], (int) (LAMBDA*pc), 3600* 8 * f, 3600 * 8 * (f + 1) - 1);
            slotList.add(slot);
        }

        CDSsq3T t      = new CDSsq3T();
        t.current    = START;           /* set the clock                         */
        t.arrival    = s.getArrival(r,  t.current); /* schedule the first arrival            */
        t.completion = INFINITY;        /* the first event can't be a completion */

        CDSsq3Area area = new CDSsq3Area();
        area.initAreaParas();

        while ((t.arrival < STOP) || (number > 0)) {
            t.next          = Math.min(t.arrival, t.completion);  /* next event time   */
            if (number > 0)  {                               /* update integrals  */
                area.node    += (t.next - t.current) * number;
                area.queue   += (t.next - t.current) * (number - 1);
                area.service += (t.next - t.current);
            }
            t.current       = t.next;                    /* advance the clock */

            if (t.current == t.arrival)  {               /* process an arrival */
                number++;
                t.arrival     = s.getArrival(r,  t.current);
                if (t.arrival > STOP)  {
                    t.last      = t.current;
                    t.arrival   = INFINITY;
                }
                if (number == 1){

                    t.completion = t.current + s.getService(r, 97 , TS_CD);}
            }
            else {                                        /* process a completion */
                index++;
                number--;
                if (number > 0){

                    t.completion = t.current + s.getService(r, 45, TS_CD);}
                else
                    t.completion = INFINITY;
            }
        }

        DecimalFormat f = new DecimalFormat("###0.00");

        System.out.println("   average interarrival time =   " + f.format(t.last / index));
        System.out.println("   average wait ............ =   " + f.format(area.node / index));
        System.out.println("   average delay ........... =   " + f.format(area.queue / index));
        System.out.println("   average service time .... =   " + f.format(area.service / index));
        System.out.println("   average # in the node ... =   " + f.format(area.node / t.current));
        System.out.println("   average # in the queue .. =   " + f.format(area.queue / t.current));
        System.out.println("   utilization ............. =   " + f.format(area.service / t.current));
    }


    double exponential(double m, Rngs r) {
        /* ---------------------------------------------------
         * generate an Exponential random variate, use m > 0.0
         * ---------------------------------------------------
         */
        return (-m * Math.log(1.0 - r.random()));
    }

    double getArrival(Rngs r, double currentTime) {
        /* --------------------------------------------------------------
         * generate the next arrival time, exponential with rate given by the current time slot
         * --------------------------------------------------------------
         */
        r.selectStream(0);

        int index = TimeSlotController.timeSlotSwitch(slotList, currentTime);

        sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / (3600*24)), r);
        return (sarrival);
    }



    double getService(Rngs r, int streamIndex, double serviceTime) {
        r.selectStream(1 + streamIndex);
        return (exponential(serviceTime, r));
    }

}
