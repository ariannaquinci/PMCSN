package org.example;
import org.example.libraries.MsqEvent;
import org.example.libraries.MsqSum;
import org.example.libraries.MsqT;
import org.example.utils.Estimate;
import org.example.libraries.Rngs;
import org.example.utils.TimeSlot;
import org.example.utils.TimeSlotController;
import java.util.ArrayList;
import java.util.List;
import static org.example.infiniteHorizon.VehicleInfiniteHorizon.writeFile;
import static org.example.utils.ConstantData.*;
import static org.example.utils.Events.*;
import static org.example.utils.NormalService.getServiceNormal;

public class VehicleImprovedFiniteSampling {

    /*document check */
    static List<Double> responseTimesDocCheck = new ArrayList<>();
    static List<Double> interarrivalsDocCheck = new ArrayList<>();
    static List<Double> delaysDocCheck = new ArrayList<>();
    static List<Double> avgPopulationsDocCheck = new ArrayList<>();
    static List<Double> allAbandonsDocCheck = new ArrayList<>();
    static List<Double> utilizationsDocCheck = new ArrayList<>();
    static List<Double> serviceTimesDocCheck = new ArrayList<>();

    /* vehicle inspection */
    static List<Double> responseTimesVehicleInspection = new ArrayList<>();
    static List<Double> interarrivalsVehicleInspection = new ArrayList<>();
    static List<Double> delaysVehicleInspection = new ArrayList<>();
    static List<Double> avgPopulationsVehicleInspection = new ArrayList<>();
    static List<Double> allAbandonsVehicleInspection = new ArrayList<>();
    static List<Double> skipsCountersVehicleInspection = new ArrayList<>();
    static List<Double> utilizationsVehicleInspection = new ArrayList<>();
    static List<Double> serviceTimesVehicleInspection = new ArrayList<>();


    static final double START = 0.0;            /* initial (open the door)        */
    static final double STOP = 90*24 * 3600;        /* terminal (close the door) time */
    static double sarrival = START;

    static List<TimeSlot> slotList = new ArrayList<>();
    static int SAMPLING_RATE = 24 * 60*60;
    static int actual_rate = SAMPLING_RATE;

    static double areaDocCheck = 0.0;
    static long indexDocCheck = 0;
    static double areaVehicleInsp = 0.0;
    static long indexVehicleInsp = 0;
    static long simulation(long seed, Rngs r) throws Exception {
        sarrival = START;

        /* stream index for the rng */
        int streamIndex = 1;

        /* population counter for every node */
        long numberDocCheck = 0;

        long classOneTotalPopulation = 0;
        long classTwoTotalPopulation = 0;
        long firstClassJobInQueue = 0;
        long secondClassJobInQueue = 0;

        int e;      /* next event index */
        int s;      /* server index */



        /* time integrated number for every node */


        double service;     /* it will contain the service times */

        /* abandons counter for document check and vehicle inspection */
        long abandonsCounterDocCheck = 0;
        long abandonsCounterVehicleInspection = 0;

        /* abandons list for document check and vehicle inspection */
        List<Double> abandonsDocCheck = new ArrayList<>();
        List<Double> abandonsVehicleInspection = new ArrayList<>();

        /* skip list for vehicle inspection */
        List<Double> skipsVehicleInspection = new ArrayList<>();

        List<Integer> VehicleInspectionPriorityClassService = new ArrayList<>();

        for (int i = 0; i < SERVERS_VEHICLE_INSPECTION; i++) {
            VehicleInspectionPriorityClassService.add(0);
        }

        /* skip counter for vehicle inspection */
        long skipCounterVehicleInspection = 0;

        /* first completion for every node */
        double docCheckFirstCompletion = 0;


        double vehicleInspectionFirstCompletion = 0;
        r.plantSeeds(seed);

        /* time slots initialization */

        for (int f = 0; f < 3; f++) {
            TimeSlot slot = new TimeSlot(PERCENTAGE[f], (int)(LAMBDA*pa/2), 3600*8 * f, 3600*8 * (f + 1) - 1);
            slotList.add(slot);
        }

        /* events array initialization */
        MsqEvent[] events = new MsqEvent[
                ALL_EVENTS_CAR_DOC +
                        ALL_EVENTS_VEHICLE_INSPECTION
                ];


        /* sum array initialization (to keep track of services) */
        MsqSum[] sum = new MsqSum[ALL_EVENTS_CAR_DOC +  ALL_EVENTS_VEHICLE_INSPECTION ];
        for (s = 0; s < ALL_EVENTS_CAR_DOC  + ALL_EVENTS_VEHICLE_INSPECTION ; s++) {
            events[s] = new MsqEvent();
            sum[s] = new MsqSum();
        }

        /* clock initialization */
        MsqT t = new MsqT();
        t.current = START;

        /* generating the first arrival */
        events[0].t = getArrival(r, 11, t.current);
        events[0].x = 1;

        /* all other servers are initially idle */
        for (s = 1; s < ALL_EVENTS_CAR_DOC  + ALL_EVENTS_VEHICLE_INSPECTION ; s++) {
            events[s].t = START;
            events[s].x = 0;
            sum[s].service = 0.0;
            sum[s].served = 0;
        }



        /* START ITERATION */

        /* skip */

        while ((events[0].x != 0)) {


            if (!skipsVehicleInspection.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 2].t = skipsVehicleInspection.get(0);
                events[ALL_EVENTS_CAR_DOC +  ALL_EVENTS_VEHICLE_INSPECTION - 2].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 2].x = 0;
            }

            /* abandons */
            if (!abandonsDocCheck.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC - 1].t = abandonsDocCheck.get(0);
                events[ALL_EVENTS_CAR_DOC - 1].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC - 1].x = 0;
            }


            if (!abandonsVehicleInspection.isEmpty()) {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1].t = t.current;
                events[ALL_EVENTS_CAR_DOC  + ALL_EVENTS_VEHICLE_INSPECTION - 1].x = 1;
            } else {
                events[ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1].x = 0;
            }




            e = nextEvent(events);    /* next event index */
            t.next = events[e].t;       /* next event time */


            /* update integrals */
            areaDocCheck += (t.next - t.current) * numberDocCheck;

            areaVehicleInsp += (t.next - t.current) * (classOneTotalPopulation + classTwoTotalPopulation);

            t.current = t.next;     /* advance the clock */

            if (e == ARRIVAL_EVENT_CAR_DOC - 1) {
                /* document check arrival */
                numberDocCheck++;

                /* generate the next arrival */
                events[ARRIVAL_EVENT_CAR_DOC - 1].t = getArrival(r, 22, t.current);
                if (events[ARRIVAL_EVENT_CAR_DOC - 1].t > STOP)
                    events[ARRIVAL_EVENT_CAR_DOC - 1].x = 0;

                /* if there's no queue, put a job on service */
                if (numberDocCheck <= SERVERS_CAR_DOC) {
                  //  service = getService(r, 33, TS_DOC_CARS);
                    service = getServiceNormal(r, (int) (TS_DOC_CARS*0.1),45,900,TS_DOC_CARS);

                    s = findIdleDocCheck(events);
                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                    events[s].x = 1;
                }

            } else if (e == ALL_EVENTS_CAR_DOC - 1) {
                /* document check abandon*/

                abandonsCounterDocCheck++;
                abandonsDocCheck.remove(0);

            }else if (e == ALL_EVENTS_CAR_DOC ) {
                /* vehicle inspection arrival */

                events[ALL_EVENTS_CAR_DOC ].x = 0;
                boolean abandon =generateAbandon(r, 60, P2);
                if(abandon){
                    double abandonTime=t.current+0.01;
                    abandonsDocCheck.add(abandonTime);

                }else {

                    service = getServiceNormal(r, (int) (TS_VEHICLE_INSPECTION_CARS*0.2),75, 1800,TS_VEHICLE_INSPECTION_CARS);

                    //service = getService(r, 77, TS_VEHICLE_INSPECTION_CARS);
                    if (service < 360) {
                        /* first queue */
                        classOneTotalPopulation++;
                    } else {
                        /* second queue */
                        classTwoTotalPopulation++;
                    }

                    if (classOneTotalPopulation + classTwoTotalPopulation <= SERVERS_VEHICLE_INSPECTION) {
                        /* the total node population is below the total number of servers */
                        s = findIdleVehicleInspection(events);

                        /* mark s as service for the first/second queue */
                        // bind server index with job type into the array
                        if (service < 360) {
                            try {
                                // small job ( without bags)
                                VehicleInspectionPriorityClassService.set(s - (ALL_EVENTS_CAR_DOC + 1), 1);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        } else {
                            try {
                                // big job
                                VehicleInspectionPriorityClassService.set(s - (ALL_EVENTS_CAR_DOC + 1), 2);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }

                        sum[s].service += service;
                        sum[s].served++;
                        events[s].t = t.current + service;
                        events[s].x = 1;
                    } else {
                        //UPDATE THE NUMBER OF JOBS IN QUEUE
                        if (service < 360)
                            firstClassJobInQueue++;
                        else secondClassJobInQueue++;
                    }
                }


            } else if ((e >= ALL_EVENTS_CAR_DOC + ARRIVAL_EVENT_VEHICLE_INSPECTION)
                    && (e < ALL_EVENTS_CAR_DOC + ARRIVAL_EVENT_VEHICLE_INSPECTION + SERVERS_VEHICLE_INSPECTION)
            ) {
                //vehicle inspection service

                boolean isFromFirstQueue = (VehicleInspectionPriorityClassService.get(e - (ALL_EVENTS_CAR_DOC  + 1)) == 1);
                boolean isFromSecondQueue = (VehicleInspectionPriorityClassService.get(e - (ALL_EVENTS_CAR_DOC +  1)) == 2);

                boolean skip = false;

                if (isFromFirstQueue) {
                    skip = generateSkipAlternative(r, 88, classOneTotalPopulation - SERVERS_VEHICLE_INSPECTION);
                } else if (isFromSecondQueue) {
                    skip = generateSkipAlternative(r, 99, classTwoTotalPopulation - SERVERS_VEHICLE_INSPECTION);
                } else {
                    throw new Exception("Unexpected behaviour");
                }

                //
                if (isFromFirstQueue)
                    classOneTotalPopulation--;
                else
                    classTwoTotalPopulation--;

                // SKIP caused by congestion
                if (skip) {
                    double skipTime = t.current + 0.01;
                    skipsVehicleInspection.add(skipTime);
                    VehicleInspectionPriorityClassService.set(e - (ALL_EVENTS_CAR_DOC +  1), 0);

                } else {
                    // Update data of vehicle inspection queue and generate possible abandon
                    if (vehicleInspectionFirstCompletion == 0)
                        vehicleInspectionFirstCompletion = t.current;

                    // update number
                    indexVehicleInsp++;

                    /* abandons are generated only if the vehicle inspection has not been skipped */
                    boolean abandon = generateAbandon(r, 110, P3);
                    if (abandon) {
                        double abandonTime = t.current + 0.02;      // 0.02 not to overlap an eventual skip
                        VehicleInspectionPriorityClassService.set(e - (ALL_EVENTS_CAR_DOC + 1), 0);
                        abandonsVehicleInspection.add(abandonTime);
                    }
                }

                s = e;

                // Now, there is idle server, so re-generate service time for queued job
                if (firstClassJobInQueue >= 1) {
                    firstClassJobInQueue--;
                    // GENERATE A SERVICE LESS THAN 10 SECONDS
                    do {
                        service = getServiceNormal(r, (int) (TS_VEHICLE_INSPECTION_CARS*0.2), 120, 1800,TS_VEHICLE_INSPECTION_CARS);

                        //service = getService(r, 121, TS_VEHICLE_INSPECTION_CARS);
                    } while (!(service < 360));
                    VehicleInspectionPriorityClassService.set(s - (ALL_EVENTS_CAR_DOC + 1), 1);
                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                    events[s].x = 1;
                } else if (secondClassJobInQueue >= 1) {
                    secondClassJobInQueue--;
                    // GENERATE A SERVICE GREATER THEN 10 SECONDS
                    do {
                        service = getServiceNormal(r, (int) (TS_VEHICLE_INSPECTION_CARS*0.1),132, 600,TS_VEHICLE_INSPECTION_CARS);

                        //  service = getService(r, 132, TS_VEHICLE_INSPECTION_CARS);
                    } while ((service < 360));
                    VehicleInspectionPriorityClassService.set(s - (ALL_EVENTS_CAR_DOC + 1), 2);
                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                    events[s].x = 1;
                } else
                    events[s].x = 0;


            } else if (e == ALL_EVENTS_CAR_DOC +  ALL_EVENTS_VEHICLE_INSPECTION - 2) {
                //vehicle inspection SKIP
                indexVehicleInsp++;
                skipCounterVehicleInspection++;
                skipsVehicleInspection.remove(0);

            } else if (e == ALL_EVENTS_CAR_DOC +  ALL_EVENTS_VEHICLE_INSPECTION - 1) {
                /*vehicle inspection abandon  */
                abandonsCounterVehicleInspection++;
                abandonsVehicleInspection.remove(0);

            } else {
                /* document check service */
                if (docCheckFirstCompletion == 0)
                    docCheckFirstCompletion = t.current;

                indexDocCheck++;
                numberDocCheck--;



                events[ALL_EVENTS_CAR_DOC].t = t.current;
                events[ALL_EVENTS_CAR_DOC].x = 1;


                /* if there's queue, put a job in queue on service on this server */
                s = e;
                if (numberDocCheck >= SERVERS_CAR_DOC) {
            //        service = getService(r, 220, TS_DOC_CARS);
                    service = getServiceNormal(r, (int) (TS_DOC_CARS*0.1),220, 600,TS_DOC_CARS);

                    sum[s].service += service;
                    sum[s].served++;
                    events[s].t = t.current + service;
                } else {
                    /* if there's no queue, deactivate this server */
                    events[s].x = 0;
                }

            }


        }

        /* SAVE STATISTICS */

        /* DOCUMENT CHECK */
    //    responseTimesDocCheck.add(areaDocCheck / indexDocCheck);
        interarrivalsDocCheck.add((events[ARRIVAL_EVENT_CAR_DOC - 1].t) / indexDocCheck);
        allAbandonsDocCheck.add((double) abandonsCounterDocCheck);

        double docCheckFinalTime = 0;
        double docCheckMean = 0;
        for (s = 1; s <= SERVERS_CAR_DOC; s++) {
            docCheckMean += events[s].t;
            if (events[s].t > docCheckFinalTime)
                docCheckFinalTime = events[s].t;
        }

        double docCheckActualTime = docCheckFinalTime - docCheckFirstCompletion;

        avgPopulationsDocCheck.add(areaDocCheck / docCheckActualTime);

        for (s = 1; s <= SERVERS_CAR_DOC; s++)          /* adjust area to calculate */
            areaDocCheck -= sum[s].service;                 /* averages for the queue   */

        delaysDocCheck.add(areaDocCheck / indexDocCheck);

        double sumUtilizations = 0.0;
        double sumServices = 0.0;
        double sumServed = 0.0;


        for (s = 1; s <= SERVERS_CAR_DOC; s++) {
            sumUtilizations += sum[s].service / docCheckActualTime;
            sumServices += sum[s].service;
            sumServed += sum[s].served;
        }

        utilizationsDocCheck.add(sumUtilizations / SERVERS_CAR_DOC);
        serviceTimesDocCheck.add(sumServices / sumServed);



        /*vehicle inspection*/

      //  responseTimesVehicleInspection.add(areaVehicleInsp / indexVehicleInsp);
        interarrivalsVehicleInspection.add((events[ALL_EVENTS_CAR_DOC ].t) / indexVehicleInsp);
        allAbandonsVehicleInspection.add((double) abandonsCounterVehicleInspection);
        skipsCountersVehicleInspection.add((double) skipCounterVehicleInspection);

        double vehicleinspectionFinalTime = 0;
        for (s = ALL_EVENTS_CAR_DOC  + ARRIVAL_EVENT_VEHICLE_INSPECTION; s <= ALL_EVENTS_CAR_DOC   + SERVERS_VEHICLE_INSPECTION; s++) {
            if (events[s].t > vehicleinspectionFinalTime)
                vehicleinspectionFinalTime = events[s].t;
        }

        double vehicleinspectionActualTime = vehicleinspectionFinalTime - vehicleInspectionFirstCompletion;

        avgPopulationsVehicleInspection.add(areaVehicleInsp / vehicleinspectionActualTime);

        for (s = ALL_EVENTS_CAR_DOC + ARRIVAL_EVENT_VEHICLE_INSPECTION; s <= ALL_EVENTS_CAR_DOC + SERVERS_VEHICLE_INSPECTION; s++)          /* adjust area to calculate */
            areaVehicleInsp -= sum[s].service;                                                                /* averages for the queue   */

        delaysVehicleInspection.add(areaVehicleInsp/ indexVehicleInsp);

        sumUtilizations = 0.0;
        sumServices = 0.0;
        sumServed = 0.0;


        for (s = ALL_EVENTS_CAR_DOC  + ARRIVAL_EVENT_VEHICLE_INSPECTION; s <= ALL_EVENTS_CAR_DOC  + SERVERS_VEHICLE_INSPECTION; s++) {
            sumUtilizations += sum[s].service / vehicleinspectionActualTime;
            sumServices += sum[s].service;
            sumServed += sum[s].served;
        }

        utilizationsVehicleInspection.add(sumUtilizations / SERVERS_VEHICLE_INSPECTION);
        serviceTimesVehicleInspection.add(sumServices / sumServed);

        r.selectStream(255);
        return r.getSeed();
    }


    static boolean generateSkipAlternative(Rngs rngs, int streamIndex, long queueSize) {
        // Seleziona il flusso appropriato
        rngs.selectStream(1 + streamIndex);

        // Definisci i limiti upper_bound e lower_bound
        double upperBound = 13;
        double lowerBound =0;

        // Calcola il coefficiente e l'intercetta
        double coefficient = 80 / (upperBound - lowerBound); // 20.4534
        double intercept = 80 - (80 * upperBound) / (upperBound - lowerBound); // -36.0

        // Calcola y usando la formula lineare
        double y = coefficient * queueSize + intercept;

        // Calcola la probabilità di skip come specificato
        double percentage = y >= 0 ? Math.min(0.8, y / 100) : 0;

        // Genera un valore randomico e confronta con la percentuale
        return rngs.random() <= percentage;
    }

    static boolean generateSkip(Rngs rngs, int streamIndex, long queueSize) {
        rngs.selectStream(1 + streamIndex);
        double percentage = Math.min(0.8, (0.444444 * queueSize - 291.555555) / 100);
        return rngs.random() <= percentage;
    }


    // this function generate a true value with (percentage * 100) % probability, oth. false
    static boolean generateAbandon(Rngs rngs, int streamIndex, double percentage) {
        rngs.selectStream(1 + streamIndex);
        return rngs.random() <= percentage;
    }

    static boolean isSubscribed(Rngs rngs, int streamIndex, double percentage) {
        rngs.selectStream(224);
        return rngs.random() <= percentage;
    }



    static int findIdleDocCheck(MsqEvent[] events) {
        /* -----------------------------------------------------
         * return the index of the available server idle longest
         * -----------------------------------------------------
         */
        int s;

        int i = 1;

        while (events[i].x == 1)       /* find the index of the first available */
            i++;                        /* (idle) server                         */
        s = i;


        while (i < SERVERS_CAR_DOC) {         /* now, check the others to find which   */
            i++;                                     /* has been idle longest                 */
            if ((events[i].x == 0) && (events[i].t < events[s].t))
                s = i;
        }
        return (s);
    }


    static int findIdleVehicleInspection(MsqEvent[] events) {
        /* -----------------------------------------------------
         * return the index of the available server idle longest
         * -----------------------------------------------------
         */
        int s;

        int i = ALL_EVENTS_CAR_DOC+ 1;

        while (events[i].x == 1)       /* find the index of the first available */
            i++;                      /* (idle) server                         */
        s = i;
        while (i < ALL_EVENTS_CAR_DOC  + SERVERS_VEHICLE_INSPECTION) {         /* now, check the others to find which   */
            i++;                                             /* has been idle longest                 */
            if ((events[i].x == 0) && (events[i].t < events[s].t))
                s = i;
        }
        return (s);
    }

    static double exponential(double m, Rngs r) {
        /* ---------------------------------------------------
         * generate an Exponential random variate, use m > 0.0
         * ---------------------------------------------------
         */
        return (-m * Math.log(1.0 - r.random()));
    }

    static double getArrival(Rngs r, int streamIndex, double currentTime) {
        /* --------------------------------------------------------------
         * generate the next arrival time, exponential with rate given by the current time slot
         * --------------------------------------------------------------
         */
        r.selectStream(1 + streamIndex);

        int index = TimeSlotController.timeSlotSwitch(slotList, currentTime);

        sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / (3600*24)), r);

        return (sarrival);
    }

    static double getService(Rngs r, int streamIndex, double serviceTime) {
        r.selectStream(1 + streamIndex);
        return (exponential(serviceTime, r));
    }

 /*   static int nextEvent(MsqEvent[] event) {

        int e;
        int i = 0;

        while (event[i].x == 0)
            i++;
        e = i;
        while (i < ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION - 1) {
            i++;
            if ((event[i].x == 1) && (event[i].t < event[e].t))
                e = i;
        }
        return (e);
    }
*/
 static int nextEvent(MsqEvent[] event) {
     /* ---------------------------------------
      * return the index of the next event type
      * ---------------------------------------
      */
     int e;
     int i = 0;

     while (event[i].x == 0)       /* find the index of the first 'active' */
         i++;                        /* element in the event list            */
     e = i;
     while (i < ALL_EVENTS_CAR_DOC + ALL_EVENTS_VEHICLE_INSPECTION  - 1) {         /* now, check the others to find which  */
         i++;                        /* event type is most imminent          */
         if ((event[i].x == 1) && (event[i].t < event[e].t))
             e = i;
     }
     // Controlla se bisogna fare un evento di campionamento o meno
     if(event[e]!=null){
         while (event[e].t > actual_rate && actual_rate+SAMPLING_RATE<STOP){
             // Processa l'evento di campionamento stampando le statistiche
             responseTimesDocCheck.add(areaDocCheck / indexDocCheck);
             responseTimesVehicleInspection.add(areaVehicleInsp/indexVehicleInsp);
             writeFile(responseTimesDocCheck, "replication_reports", "rt_doc_check_campionamento");
             writeFile(responseTimesVehicleInspection, "replication_reports", "rt_vehicle_inspection_campionamento");
             // System.out.println(docCheckRTs);
             actual_rate += SAMPLING_RATE;
         }
     }
     return (e);
 }

    public static void main(String[] args) throws Exception {
        long[] seeds = new long[1024];
        seeds[0] =1117727262;
        Rngs r = new Rngs();
        for (int i = 0; i < 1; i++) {
            seeds[i+1] = simulation(seeds[i], r);
            System.out.println(r.getSeed());
        }

        /* files creation for interval estimation */
        String directory = "improved_model_replication_reports";

        /* DOCUMENT CHECK */
        writeFile(delaysDocCheck, directory, "delays_doc_check");
        writeFile(responseTimesDocCheck, directory, "response_times_doc_check");
        writeFile(utilizationsDocCheck, directory, "utilizations_doc_check");
        writeFile(avgPopulationsDocCheck, directory, "populations_doc_check");
        writeFile(interarrivalsDocCheck, directory, "interarrivals_doc_check");
        writeFile(allAbandonsDocCheck, directory, "abandons_doc_check");
        writeFile(serviceTimesDocCheck, directory, "service_times_doc_check");


        /*VEHICLE INSPECTION*/
        writeFile(delaysVehicleInspection, directory, "delays_vehicle_inspection");
        writeFile(responseTimesVehicleInspection, directory, "response_times_vehicle_inspection");
        writeFile(utilizationsVehicleInspection, directory, "utilizations_vehicle_inspection");
        writeFile(avgPopulationsVehicleInspection, directory, "populations_vehicle_inspection");
        writeFile(interarrivalsVehicleInspection, directory, "interarrivals_vehicle_inspection");
        writeFile(allAbandonsVehicleInspection, directory, "abandons_vehicle_inspection");
        writeFile(serviceTimesVehicleInspection, directory, "service_times_vehicle_inspection");
        writeFile(skipsCountersVehicleInspection, directory, "skips_vehicle_inspection");


        /* INTERVAL ESTIMATION */

        Estimate estimate = new Estimate();

        List<String> filenames = List.of("response_times_doc_check", "delays_doc_check", "utilizations_doc_check", "interarrivals_doc_check", "abandons_doc_check", "service_times_doc_check", "populations_doc_check",
                "response_times_vehicle_inspection", "delays_vehicle_inspection", "utilizations_vehicle_inspection", "interarrivals_vehicle_inspection", "abandons_vehicle_inspection", "service_times_vehicle_inspection", "populations_vehicle_inspection", "skips_vehicle_inspection"
        );

        for (String filename : filenames) {
            estimate.createInterval(directory, filename);
        }
    }

}
