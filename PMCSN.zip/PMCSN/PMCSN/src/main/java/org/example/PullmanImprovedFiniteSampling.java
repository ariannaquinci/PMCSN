package org.example;

import org.example.libraries.MsqEvent;
import org.example.libraries.MsqSum;
import org.example.libraries.MsqT;
import org.example.utils.Estimate;
import org.example.libraries.Rngs;
import org.example.utils.TimeSlot;
import org.example.utils.TimeSlotController;

import java.util.ArrayList;
import java.util.List;

import static org.example.infiniteHorizon.VehicleInfiniteHorizon.writeFile;
import static org.example.utils.ConstantData.*;
import static org.example.utils.Events.*;
import static org.example.utils.NormalService.getServiceNormal;

public class PullmanImprovedFiniteSampling {
    static List<Double> responseTimes = new ArrayList<>();
    static List<Double> interarrivals = new ArrayList<>();
    static List<Double> delays = new ArrayList<>();
    static List<Double> avgPopulations = new ArrayList<>();
    static List<Double> allAbandons = new ArrayList<>();
    static List<Double> utilizations = new ArrayList<>();
    static List<Double> serviceTimes = new ArrayList<>();
    static long indexPullman = 0;            /* used to count processed vehicles       */

    static final double START = 0.0;            /* initial (open the door)        */
    static final double STOP =90* 24 * 3600;        /* terminal (close the door) time */
    static double sarrival = START;
    static int SAMPLING_RATE = 24 * 60*60;
    static int actual_rate = SAMPLING_RATE;
    static List<TimeSlot> slotList = new ArrayList<>();
static double areaPullman = 0.0;           /* time integrated number in the node */
    static long simulation(long seed, Rngs r) throws Exception {
        sarrival = START;

        int streamIndex = 1;
        long classOneTotalPopulation = 0;
        long classTwoTotalPopulation = 0;
        long firstClassJobInQueue = 0;
        long secondClassJobInQueue = 0;
        int e;                      /* next event index                    */
        int s;                      /* server index                        */
       long indexServerWait = 0;



        double areaPullmanWait = 0.0;
        double service;
        long abandonCheck = 0;
        List<Double> abandon = new ArrayList<>();
        double serverFirstCompletetion = 0;

        List<Integer> serverPriorityClassService = new ArrayList<>();

        for (int i = 0; i < SERVERS_PULLMAN; i++) {
            serverPriorityClassService.add(0);
        }

        r.plantSeeds(seed);


        for (int f = 0; f < 3; f++) {
            TimeSlot slot = new TimeSlot(PERCENTAGE[f], (int)(LAMBDA*pp), 3600*8 * f, 3600*8 * (f + 1) - 1);
            slotList.add(slot);
        }

        MsqEvent[] event = new MsqEvent[ALL_EVENTS_PULLMAN];
        MsqSum[] sum = new MsqSum[ALL_EVENTS_PULLMAN];

        for (s = 0; s < ALL_EVENTS_PULLMAN; s++) {
            event[s] = new MsqEvent();
            sum[s] = new MsqSum();
        }

        MsqT t = new MsqT();
        t.current = START;

        event[0].t = getArrival(r, 24,t.current);
        event[0].x = 1;

        for (s = 1; s < SERVERS_PULLMAN; s++) {
            event[s].t = START;          /* this value is arbitrary because */
            event[s].x = 0;              /* all servers are initially idle  */
            sum[s].service = 0.0;
            sum[s].served = 0;
        }

        while ((event[0].x != 0) || (classOneTotalPopulation + classTwoTotalPopulation != 0)) {

            if (!abandon.isEmpty()) {
                event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].t = abandon.get(0);
                event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].x = 1;     // activate abandon
            } else {
                event[SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN].x = 0;     // deactivate abandon
            }

            e = nextEvent(event);                                         /* next event index */
            t.next = event[e].t;                                            /* next event time  */
            areaPullman += (t.next - t.current) * (classOneTotalPopulation + classTwoTotalPopulation);  /* update integral  */
            areaPullmanWait += (t.next - t.current) * (firstClassJobInQueue + secondClassJobInQueue);
            t.current = t.next;                                             /* advance the clock*/

            if (e == ARRIVAL_EVENT_PULLMAN - 1) {
                /* pullman arrival */
                event[0].t = getArrival(r, 48,t.current);

                if (event[0].t > STOP)
                    event[0].x = 0;

                event[ALL_EVENTS_PULLMAN - 1].x = 0;

                // generate, with probability P1, an abandon
                boolean isAbandon = generateAbandon(r, 72, P1);
                if (isAbandon) {  // add an abandon
                    double abandonTime = t.current + 0.01;  // this will be the next abandon time (it must be small in order to execute the abandon as next event)
                    abandon.add(abandonTime);
                } else{
                    // if there isn't abandon process arrival
                    service=getServiceNormal(r,240,225,10800,2400);

                    if (service < 2400) {
                        /* first queue */
                        classOneTotalPopulation++;
                    } else {
                        /* second queue */
                        classTwoTotalPopulation++;
                    }
                    if (classOneTotalPopulation + classTwoTotalPopulation <= SERVERS_PULLMAN) {
                        /* the total node population is below the total number of servers */
                        s = findServer(event);

                        /* mark s as service for the first/second queue */
                        // bind server index with job type into the array
                        if (service < 2400) {
                            try {
                                // small job ( without bags)
                                serverPriorityClassService.set(s - 1, 1);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        else {
                            try {
                                // big job
                                serverPriorityClassService.set(s - 1, 2);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }

                        sum[s].service += service;
                        sum[s].served++;
                        event[s].t = t.current + service;
                        event[s].x = 1;
                    }else{
                        //UPDATE THE NUMBER OF JOBS IN QUEUE
                        indexServerWait++;

                        if (service<2400)
                            firstClassJobInQueue ++;
                        else secondClassJobInQueue++;
                    }


                }
            }else if (e == SERVERS_PULLMAN + ABANDON_EVENT_PULLMAN) {
                abandonCheck++;
                abandon.remove(0);

            } else if ( (e >= ARRIVAL_EVENT_PULLMAN) && (e <= SERVERS_PULLMAN) ) {
                boolean isFromFirstQueue = (serverPriorityClassService.get(e - 1) == 1);
                if (isFromFirstQueue)
                    classOneTotalPopulation--;
                else
                    classTwoTotalPopulation--;

                if (serverFirstCompletetion == 0)
                    serverFirstCompletetion = t.current;


                boolean isAbandon = generateAbandon(r, 120, P1);
                indexPullman++;
                if (isAbandon) {
                    double abandonTime = t.current + 0.01;
                    abandon.add(abandonTime);
                }


                s = e;
                // Now, there is idle server, so re-generate service time for queued job
                if (firstClassJobInQueue >= 1) {
                    firstClassJobInQueue --;
                    // GENERATE A SERVICE LESS THAN 2400 SECONDS
                    do {
                        service=getServiceNormal(r,240,144,10800,2400);

                    } while (!(service < 2400));
                    serverPriorityClassService.set(s - 1, 1);
                    sum[s].service += service;
                    sum[s].served++;
                    event[s].t = t.current + service;
                    event[s].x = 1;
                } else if (secondClassJobInQueue >= 1) {
                    secondClassJobInQueue --;
                    // GENERATE A SERVICE GREATER THEN 2400 SECONDS
                    do {
                        service=getServiceNormal(r,240,45,10800,2400);

                    } while ((service < 2400));
                    serverPriorityClassService.set(s - 1, 2);
                    sum[s].service += service;
                    sum[s].served++;
                    event[s].t = t.current + service;
                    event[s].x = 1;
                } else
                    event[s].x = 0;
            }else{
                throw new Exception("Unexpected behaviour!");
            }
        }


        /* SAVE STATISTICS */
        responseTimes.add(areaPullman / indexPullman);
        interarrivals.add((event[0].t) / indexPullman);
        allAbandons.add((double) abandonCheck);

        double finalTime = 0;
        for (s = 1; s <= SERVERS_PULLMAN; s++) {
            if (event[s].t > finalTime)
                finalTime = event[s].t;
        }

        double actualTime = finalTime - serverFirstCompletetion;

        avgPopulations.add(areaPullman / actualTime);

        for (s = 1; s <= SERVERS_PULLMAN; s++)          /* adjust area to calculate */
            areaPullman -= sum[s].service;                 /* averages for the queue   */

        delays.add(areaPullman / indexPullman);

        double sumUtilizations = 0.0;
        double sumServices = 0.0;
        double sumServed = 0.0;


        for (s = 1; s <= SERVERS_PULLMAN; s++) {
            sumUtilizations += sum[s].service / actualTime;
            sumServices += sum[s].service;
            sumServed += sum[s].served;
        }

        utilizations.add(sumUtilizations / SERVERS_PULLMAN);
        serviceTimes.add(sumServices / sumServed);

        r.selectStream(255);
        return r.getSeed();
    }

    // this function generate a true value with (percentage * 100) % probability, oth. false
    static boolean generateAbandon(Rngs rngs, int streamIndex, double percentage) {
        rngs.selectStream(1 + streamIndex);
        return rngs.random() <= percentage;
    }


    static double exponential(double m, Rngs r) {
        /* ---------------------------------------------------
         * generate an Exponential random variate, use m > 0.0
         * ---------------------------------------------------
         */
        return (-m * Math.log(1.0 - r.random()));
    }


    static double getArrival(Rngs r, int streamIndex, double currentTime) {
        /* --------------------------------------------------------------
         * generate the next arrival time, exponential with rate given by the current time slot
         * --------------------------------------------------------------
         */
        r.selectStream(1 + streamIndex);

        int index = TimeSlotController.timeSlotSwitch(slotList, currentTime);

        sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / (3600*24)), r);
        return (sarrival);
    }


    static double getService(Rngs r, int streamIndex, double serviceTime) {
        r.selectStream(1 + streamIndex);
        return (exponential(serviceTime, r));
    }

    static int nextEvent(MsqEvent[] event) {
        /* ---------------------------------------
         * return the index of the next event type
         * ---------------------------------------
         */

        int e;
        int i = 0;

        while (event[i].x == 0)       /* find the index of the first 'active' */
            i++;                        /* element in the event list            */
        e = i;
        while (i < ALL_EVENTS_PULLMAN  - 1) {         /* now, check the others to find which  */
            i++;                        /* event type is most imminent          */
            if ((event[i].x == 1) && (event[i].t < event[e].t))
                e = i;
        }
        // Controlla se bisogna fare un evento di campionamento o meno
        if(event[e]!=null){
            while (event[e].t > actual_rate && actual_rate+SAMPLING_RATE<STOP){
                // Processa l'evento di campionamento stampando le statistiche

                responseTimes.add(areaPullman/indexPullman);
                System.out.println(responseTimes);
                writeFile(responseTimes, "improved_model_replication_reports", "rt_pullman_campionamento");

                actual_rate += SAMPLING_RATE;
            }
        }
        return (e);
    }


    static int findServer(MsqEvent[] event) {
        /* -----------------------------------------------------
         * return the index of the available server idle longest
         * -----------------------------------------------------
         */
        int s;

        int i = 0;

        while (event[i].x == 1)       /* find the index of the first available */
            i++;                        /* (idle) server                         */
        s = i;
        while (i < SERVERS_PULLMAN) {         /* now, check the others to find which   */
            i++;                                             /* has been idle longest                 */
            if ((event[i].x == 0) && (event[i].t < event[s].t))
                s = i;
        }
        return (s);
    }

    public static void main(String[] args) throws Exception {
        long[] seeds = new long[1024];
        seeds[0] =1117727262;
        Rngs r = new Rngs();
        for (int i = 0; i < 150; i++) {
            seeds[i + 1] = simulation(seeds[i], r);
        }

        /* files creation for interval estimation */
        String directory = "improved_model_replication_reports";

        writeFile(delays, directory, "delays_pullman");
        writeFile(responseTimes, directory, "response_times_pullman");
        writeFile(utilizations, directory, "utilizations_pullman");
        writeFile(avgPopulations, directory, "populations_pullman");
        writeFile(interarrivals, directory, "interarrivals_pullman");
        writeFile(allAbandons, directory, "abandons_pullman");
        writeFile(serviceTimes, directory, "service_times_pullman");

        /* INTERVAL ESTIMATION */

        Estimate estimate = new Estimate();
        List<String> filenames = List.of("response_times_pullman", "delays_pullman", "utilizations_pullman", "interarrivals_pullman", "abandons_pullman", "service_times_pullman", "populations_pullman");

        for (String filename : filenames) {
            estimate.createInterval(directory, filename);
        }
    }
}
