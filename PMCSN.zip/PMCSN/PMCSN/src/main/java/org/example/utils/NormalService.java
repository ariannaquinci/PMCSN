package org.example.utils;

import org.example.libraries.Rngs;

public class NormalService {
    public static double getServiceNormal(Rngs r, int variance, int streamIndex, int b, double serviceTime) {
        r.selectStream(1 + streamIndex);
        return normalTruncated(serviceTime,variance,3,b, r);
    }

    public static double normalTruncated(double m, double s, double a, double b, Rngs rngs)  {

        double u;
        double z;
        Rvms rvms = new Rvms();
        while(true) {
            u = rngs.random();
            z = rvms.idfNormal(m, s, u);

            if (z >= a && z<=b){
                return z;
            }
        }


    }
}
