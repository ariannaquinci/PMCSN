package org.example.libraries;

public class MsqT {
    public double current;                   /* current time                       */
    public double next;                      /* next (most imminent) event time    */
}
