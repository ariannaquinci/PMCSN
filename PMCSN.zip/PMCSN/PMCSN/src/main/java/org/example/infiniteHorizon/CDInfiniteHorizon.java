package org.example.infiniteHorizon;

import org.example.libraries.Rngs;
import org.example.utils.Estimate;
import org.example.utils.TimeSlot;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.example.utils.ConstantData.*;
import static org.example.utils.Events.*;

public class CDInfiniteHorizon {

    static class SsqT {
        double current;                   /* current time                       */
        double next;                      /* next (most imminent) event time    */
    }

    static class SsqSum {                      /* accumulated sums of                */
        double service;                   /*   service times                    */
        long served;                      /*   number served                    */
    }

    static class SsqEvent {                     /* the next-event list    */
        double t;                         /*   next event time      */
        int x;                         /*   event status, 0 or 1 */
    }

    static double START = 0.0;            /* initial (open the door)        */
    static double STOP = Double.POSITIVE_INFINITY;        /* terminal (close the door) time */
    static double sarrival = START;

    static List<TimeSlot> slotList = new ArrayList<>();

    public static void main(String[] args) {

        /* population counter*/
        long populationCD = 0;

        int e;      /* next event index */

        /* processed jobs counter */
        long indexCD = 0;

        /* time integrated number*/
        double areaCD = 0.0;

        double service;     /* it will contain the service times */

        CDInfiniteHorizon m = new CDInfiniteHorizon();
        Rngs r = new Rngs();
        r.plantSeeds(0);

        /* time slots initialization */
        for (int f = 0; f < 3; f++) {
            System.out.println(PERCENTAGE[f] + "; " + (int) (LAMBDA * pc));
            TimeSlot slot = new TimeSlot(PERCENTAGE[f], (int) (LAMBDA * pc), 3600 * 8 * f, 3600 * 8 * (f + 1) - 1);
            slotList.add(slot);
        }

        /* batch parameters */
        int k =1024*7;
        int b = 1024*15;
        /* lists for batch simulation */

        /* waiting times */
        List<Double> delaysCDCheck = new ArrayList<>();

        /* response times */
        List<Double> responseTimesCDCheck = new ArrayList<>();
        List<Double> responseTimesCDCumulative = new ArrayList<>();
        /* utilizations */
        List<Double> utilizationsCDCheck = new ArrayList<>();

        /* system populations */
        List<Double> avgPopulationsCDCheck = new ArrayList<>();

        /* interarrivals */
        List<Double> interarrivalsCDCheck = new ArrayList<>();

        /* service times */
        List<Double> serviceTimesCDCheck = new ArrayList<>();

        double currentBatchStartingTime = 0;
        double currentFirstArrivalTimeCDCheck = 0;

        long batchCounter = 0;

        /* events array initialization */
        SsqEvent[] events = new SsqEvent[2]; // 1 for arrival, 1 for completion

        /* sum array initialization (to keep track of services) */
        SsqSum sum = new SsqSum();
        sum.service = 0.0;
        sum.served = 0;

        /* clock initialization */
        SsqT t = new SsqT();
        t.current = START;

        /* generating the first arrival */
        events[0] = new SsqEvent();
        events[1] = new SsqEvent();
        events[0].t = m.getArrival(r, 250, t.current); // First arrival
        events[0].x = 1; // Arrival event is active

        events[1].t = START; // No completion yet
        events[1].x = 0; // Completion event is inactive initially

        /* START ITERATION */
        while ((events[0].x != 0)) { // While there are still arrivals

            if (indexCD != 0 && indexCD % b == 0) {

                /* new batch */
                batchCounter++;

                responseTimesCDCheck.add(areaCD / indexCD);
                if (responseTimesCDCumulative.isEmpty()) {
                    responseTimesCDCumulative.add(responseTimesCDCheck.get(0));
                } else {
                    double previousCumulative = responseTimesCDCumulative.get(responseTimesCDCumulative.size() - 1);
                    double currentResponseTime = responseTimesCDCheck.get(responseTimesCDCheck.size() - 1);
                    double newCumulativeMean = (previousCumulative * (responseTimesCDCumulative.size()) + currentResponseTime) / (responseTimesCDCumulative.size() + 1);
                    responseTimesCDCumulative.add(newCumulativeMean);
                }

                interarrivalsCDCheck.add((events[ARRIVAL_EVENT_CD - 1].t - currentFirstArrivalTimeCDCheck) / indexCD);


                double actualTime = t.current - currentBatchStartingTime;
                avgPopulationsCDCheck.add(areaCD / actualTime);

                double delay = events[1].t - t.current;  // Tempo di attesa
                delaysCDCheck.add(delay);
                utilizationsCDCheck.add(sum.service / (t.current - START));

                serviceTimesCDCheck.add(sum.service / sum.served);

                areaCD = 0;
                indexCD = 0;

                /* final updates */
                currentBatchStartingTime = t.current;
                currentFirstArrivalTimeCDCheck = events[0].t;
            }

            if (batchCounter == k)
                break;

            e = m.nextEvent(events); /* next event index */
            t.next = events[e].t; /* next event time */

            /* update integrals */
            areaCD += (t.next - t.current) * populationCD;
            t.current = t.next; /* advance the clock */

            if (e == ARRIVAL_EVENT_CD - 1) { // Process an arrival

                populationCD++;

                /* generate the next arrival */
                events[ARRIVAL_EVENT_CD - 1].t = m.getArrival(r, 2, t.current);
                if (events[ARRIVAL_EVENT_CD - 1].t > STOP)
                    events[ARRIVAL_EVENT_CD - 1].x = 0;

                /* if the server is idle, put a job in service */
                if (events[1].x == 0) {
                    service = m.getService(r, 45, TS_CD);
                    sum.service += service;
                    sum.served++;
                    events[1].t = t.current + service; // Completion time
                    events[1].x = 1; // Activate the service
                }

            } else { // Process a completion

                indexCD++;
                populationCD--;

                if (populationCD > 0) { // If there are jobs in the queue, serve the next one
                    service = m.getService(r, 225, TS_CD);
                    sum.service += service;
                    sum.served++;
                    events[1].t = t.current + service; // New completion time
                } else {
                    events[1].x = 0; // No more jobs, server is idle
                }
            }
        }

        System.out.println("END OF ITERATION");

        /* BATCH SIMULATION RESULTS */
        System.out.println("Completed " + batchCounter + " batches");

        /* Write the results to files */
        String directory = "batch_reports";
        writeFile(delaysCDCheck, directory, "delays_cd_check");
        writeFile(responseTimesCDCheck, directory, "response_times_cd_check");
        writeFile(utilizationsCDCheck, directory, "utilizations_cd_check");
        writeFile(avgPopulationsCDCheck, directory, "populations_cd_check");
        writeFile(interarrivalsCDCheck, directory, "interarrivals_cd_check");
        writeFile(serviceTimesCDCheck, directory, "service_times_cd_check");
        writeFile(responseTimesCDCumulative, directory, "cumulative_response_times_cd");

        /* INTERVAL ESTIMATION */
        Estimate estimate = new Estimate();
        List<String> filenames = List.of("response_times_cd_check", "delays_cd_check", "utilizations_cd_check", "interarrivals_cd_check", "service_times_cd_check", "populations_cd_check");
        for (String filename : filenames) {
            estimate.createInterval(directory, filename);
        }
    }

    public static void writeFile(List<Double> list, String directoryName, String filename) {
        File directory = new File(directoryName);
        BufferedWriter bw = null;

        try {
            if (!directory.exists())
                directory.mkdirs();

            File file = new File(directory, filename + ".dat");

            if (!file.exists())
                file.createNewFile();

            FileWriter writer = new FileWriter(file);
            bw = new BufferedWriter(writer);

            for (int i = 0; i < list.size(); i++) {
                bw.append(String.valueOf(list.get(i)));
                bw.append("\n");
                bw.flush();
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (bw != null) {
                    bw.flush();
                    bw.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    double exponential(double m, Rngs r) {
        return (-m * Math.log(1.0 - r.random()));
    }

    double getArrival(Rngs r, int streamIndex, double currentTime) {
        r.selectStream(1 + streamIndex);
        int index = 0;  /* forcing the first time slot, for the verification step */
        sarrival += exponential(1 / (slotList.get(index).getAveragePoisson() / (3600 * 24)), r);
        return (sarrival);
    }

    double getService(Rngs r, int streamIndex, double serviceTime) {
        r.selectStream(1 + streamIndex);
        return (exponential(serviceTime, r));
    }

    int nextEvent(SsqEvent[] event) {
        int e;
        int i = 0;
        while (event[i].x == 0) /* find the first active event */
            i++;
        e = i;
        while (i < 1) { /* there are only 2 events: arrival and completion */
            i++;
            if ((event[i].x == 1) && (event[i].t < event[e].t))
                e = i;
        }
        return e;
    }
}
